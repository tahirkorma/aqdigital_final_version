@echo off
title Stop AQ DIGITAL File Desk
echo ===========================================
echo       Stopping AQ DIGITAL Server
echo ===========================================
echo.

REM Find and terminate any process listening on port 3000
set FOUND=0
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":3000" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
    set FOUND=1
)

if "%FOUND%"=="1" (
    echo [OK] AQ DIGITAL server stopped successfully.
) else (
    echo [INFO] AQ DIGITAL server was not running.
)

echo.
timeout /t 2 >nul

@echo off
title AQ DIGITAL - Windows Build
color 0B

echo ==========================================================
echo        AQ DIGITAL File Desk - Windows Build System
echo ==========================================================
echo.

REM 1. Check Node.js
where node >nul 2>nul
if %ERRORLEVEL% equ 0 goto CHECK_DIST

echo [ERROR] Node.js is not installed on this PC.
echo Please install Node.js (LTS version) from: https://nodejs.org
echo.
pause
exit /b 1

:CHECK_DIST
echo [1/2] Compiling application bundle...
if not exist "node_modules\" call npm install
call npm run build:standalone
if %ERRORLEVEL% neq 0 goto BUILD_ERROR

echo [OK] Application bundle rebuilt in dist\.
if not exist "dist\server.cjs" goto BUILD_ERROR
goto FIND_INNO

:BUILD_ERROR
echo.
echo [ERROR] Failed to compile application bundle!
echo.
pause
exit /b 1

:FIND_INNO
echo.
echo [2/2] Checking for Inno Setup compiler...
set "ISCC="

where iscc >nul 2>nul
if %ERRORLEVEL% equ 0 set "ISCC=iscc"
if defined ISCC goto RUN_INNO

if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" set "ISCC=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if defined ISCC goto RUN_INNO

if exist "C:\Program Files\Inno Setup 6\ISCC.exe" set "ISCC=C:\Program Files\Inno Setup 6\ISCC.exe"
if defined ISCC goto RUN_INNO

if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if defined ISCC goto RUN_INNO

REM If Inno Setup command-line compiler was not found in standard paths
echo.
echo ----------------------------------------------------------
echo  Automatic compiler (ISCC.exe) was not found in default paths.
echo  You can compile easily using the Inno Setup program:
echo.
echo    1. Open "Inno Setup Compiler" from your Start Menu.
echo    2. Click File -^> Open...
echo    3. Select: installer\aq_digital_setup.iss
echo    4. Click the green "Run" button (or press Ctrl+F9).
echo    5. Your setup file will be created in dist_installer\
echo ----------------------------------------------------------
echo.
pause
exit /b 0

:RUN_INNO
echo [*] Compiling installer using: "%ISCC%"
echo.
"%ISCC%" installer\aq_digital_setup.iss
if %ERRORLEVEL% neq 0 goto INNO_ERROR

echo.
echo ==========================================================
echo  [SUCCESS] Windows Installer created!
echo  Location: dist_installer\AQ-Digital-Setup.exe
echo ==========================================================
echo.
if exist "dist_installer\AQ-Digital-Setup.exe" start "" explorer.exe /select,"dist_installer\AQ-Digital-Setup.exe"
pause
exit /b 0

:INNO_ERROR
echo.
echo [ERROR] Inno Setup compilation failed.
echo.
pause
exit /b 1

# AQ DIGITAL File Desk

Production-ready local customer file transfer, security quarantine, Microsoft Defender scanning, and document return system designed specifically for typing and print shops.

Replaces slow, compressed, virus-prone WhatsApp, email, and USB pendrive file transfers with a rapid, direct, 100% offline local Wi-Fi transfer desk.

---

## Key Features

1. **One-Scan Customer Experience**:
   - Customer phone scans desk QR code -> Connects directly to `AQ-DIGITAL` Wi-Fi -> Customer upload page opens automatically -> Customer uploads documents with zero app installation.
2. **Strict Internet Isolation**:
   - Customer devices on the local hotspot receive **no access** to the shop PC's Internet connection or internal LAN shares (SMB/RDP/NetBIOS).
3. **Rigorous File Validation & Threat Detection**:
   - Validates file signatures (magic bytes) to catch disguised executables (e.g. an `.exe` renamed to `.pdf`).
   - Blocks dangerous executable formats (`.exe`, `.bat`, `.cmd`, `.msi`, `.ps1`, `.vbs`, etc.).
   - Restricts and sanitizes filenames (preventing path traversal `../`, null bytes, and Windows device names).
4. **Microsoft Defender Antivirus Quarantine**:
   - All uploaded files pass through a multi-stage quarantine: `Incoming` -> `Quarantine` -> `Microsoft Defender Scan` -> `Clean Job Storage`.
   - Never exposes unverified or infected files.
5. **Operator Job Management**:
   - Real-time dashboard showing incoming jobs, total files, and transfer progress.
   - Immediate server-side job termination (stops chunk uploads mid-stream).
   - Global "Pause Receiving" toggle for shop rush hours.
6. **Return Document Studio & PDF Editor**:
   - Send original portal PDFs directly or use the built-in PDF Editor:
     - **Crop**: Trim unwanted portal headers/footers.
     - **Text & Stamp**: Add shop verification stamp and customer reference text.
     - **Itemized Charges**: Calculate typing (₹50), printing (₹20), scanning (₹10) with automatic total calculation.
     - Protects original PDF (never overwrites the source portal document).
7. **Secure Tokenized Customer Return**:
   - Customers keep their waiting page open and receive their completed documents via cryptographically random tokens (`/api/job/<jobToken>/document/<docToken>`).
   - Prevents directory browsing and cross-customer access.
8. **Configurable Hotspot & Storage**:
   - Change Hotspot SSID, Wi-Fi password, customer hostname, and port at any time with automatic QR regeneration.
   - Configurable automatic retention cleanup (30m, 1h, 6h, 24h, 7d, 30d, or strictly "Never").
   - Storage usage meter with 80% warning and 90% critical alerts.

---

## Quick Start

### Development Mode
```bash
npm run dev
```
Access the operator console at `http://localhost:3000`.

### Production Build
```bash
npm run build
npm start
```

### Windows Installer
Run the PowerShell build script:
```powershell
.\build_windows.ps1
```
The installer will be generated at `dist_installer\AQ-Digital-Setup.exe`.

import dgram from 'dgram';

let dnsServer: dgram.Socket | null = null;
let currentTargetIp = '192.168.137.1';

/**
 * Builds a valid DNS response packet resolving any A-record query to targetIp
 */
function buildDnsResponse(query: Buffer, ipStr: string): Buffer | null {
  try {
    const parts = ipStr.split('.').map(Number);
    if (parts.length !== 4 || parts.some((p) => isNaN(p) || p < 0 || p > 255)) {
      return null;
    }

    if (query.length < 12) return null;

    const id = query.readUInt16BE(0);

    // Find the end of the Question section
    let offset = 12;
    while (offset < query.length && query[offset] !== 0) {
      offset += query[offset] + 1;
    }
    offset += 1; // null byte terminator
    offset += 4; // QTYPE (2 bytes) + QCLASS (2 bytes)

    if (offset > query.length) return null;

    const questionSection = query.subarray(12, offset);

    // DNS Header (12 bytes) + Question + Answer (16 bytes)
    const res = Buffer.alloc(12 + questionSection.length + 16);

    // Header
    res.writeUInt16BE(id, 0);
    res.writeUInt16BE(0x8180, 2); // Flags: Standard query response, No error
    res.writeUInt16BE(1, 4);      // QDCOUNT: 1
    res.writeUInt16BE(1, 6);      // ANCOUNT: 1
    res.writeUInt16BE(0, 8);      // NSCOUNT: 0
    res.writeUInt16BE(0, 10);     // ARCOUNT: 0

    // Question Section
    questionSection.copy(res, 12);
    let ansOffset = 12 + questionSection.length;

    // Answer Section
    res.writeUInt16BE(0xc00c, ansOffset); // Name Pointer to Question QNAME (byte 12)
    ansOffset += 2;
    res.writeUInt16BE(1, ansOffset);      // TYPE: A (IPv4)
    ansOffset += 2;
    res.writeUInt16BE(1, ansOffset);      // CLASS: IN
    ansOffset += 2;
    res.writeUInt32BE(60, ansOffset);     // TTL: 60 seconds
    ansOffset += 4;
    res.writeUInt16BE(4, ansOffset);      // RDLENGTH: 4 bytes
    ansOffset += 2;

    // IPv4 Address (4 bytes)
    res[ansOffset] = parts[0];
    res[ansOffset + 1] = parts[1];
    res[ansOffset + 2] = parts[2];
    res[ansOffset + 3] = parts[3];

    return res;
  } catch {
    return null;
  }
}

/**
 * Starts a lightweight captive DNS server on UDP port 53.
 * Automatically answers any probe (captive.apple.com, connectivitycheck.gstatic.com, aqdigital, etc.)
 * with the local PC IP so captive portal auto-popup triggers reliably on mobile devices.
 */
export function startCaptiveDnsServer(targetIp: string) {
  currentTargetIp = targetIp;

  if (dnsServer) {
    return;
  }

  try {
    const socket = dgram.createSocket('udp4');

    socket.on('error', (err: any) => {
      // In container or unprivileged environments, port 53 may not be bindable.
      // Gracefully log note without crashing.
      console.log(`[Captive DNS] Note: UDP port 53 listener unavailable (${err.code || err.message}). DNS captive auto-redirect will use gateway or direct IP.`);
      try {
        socket.close();
      } catch {}
      dnsServer = null;
    });

    socket.on('message', (msg, rinfo) => {
      const response = buildDnsResponse(msg, currentTargetIp);
      if (response) {
        socket.send(response, 0, response.length, rinfo.port, rinfo.address, () => {});
      }
    });

    socket.bind(53, '0.0.0.0', () => {
      console.log(`[Captive DNS] Active on UDP port 53 -> Resolving all domains to ${currentTargetIp}`);
    });

    dnsServer = socket;
  } catch (err: any) {
    console.log('[Captive DNS] Could not initialize UDP socket:', err.message);
  }
}

export function updateCaptiveDnsTargetIp(targetIp: string) {
  currentTargetIp = targetIp;
}

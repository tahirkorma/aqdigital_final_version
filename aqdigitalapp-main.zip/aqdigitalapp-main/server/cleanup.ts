import fs from 'fs';
import path from 'path';
import { DIRS } from './storage';
import { getShopSettings, addAuditLog, getDb, saveDb } from './db';
import { RetentionPeriod } from '../src/types';

export function retentionToMs(period: RetentionPeriod): number | null {
  switch (period) {
    case '30m':
      return 30 * 60 * 1000;
    case '1h':
      return 60 * 60 * 1000;
    case '6h':
      return 6 * 60 * 60 * 1000;
    case '24h':
      return 24 * 60 * 60 * 1000;
    case '7d':
      return 7 * 24 * 60 * 60 * 1000;
    case '30d':
      return 30 * 24 * 60 * 60 * 1000;
    case 'Never':
      return null;
    default:
      return 24 * 60 * 60 * 1000;
  }
}

export async function runCleanupCycle(): Promise<{
  deletedIncomplete: number;
  deletedRejected: number;
  deletedCompleted: number;
  deletedFinalDocs: number;
}> {
  const settings = await getShopSettings();
  const now = Date.now();
  let deletedIncomplete = 0;
  let deletedRejected = 0;
  let deletedCompleted = 0;
  let deletedFinalDocs = 0;

  // 1. Incomplete transfers cleanup (in Incoming)
  const incompleteMs = retentionToMs(settings.incompleteRetention);
  if (incompleteMs !== null && fs.existsSync(DIRS.incoming)) {
    const files = fs.readdirSync(DIRS.incoming);
    for (const f of files) {
      const full = path.join(DIRS.incoming, f);
      try {
        const stat = fs.statSync(full);
        if (now - stat.mtimeMs > incompleteMs) {
          fs.unlinkSync(full);
          deletedIncomplete++;
        }
      } catch {
        // ignore locked
      }
    }
  }

  // 2. Rejected files cleanup (in Rejected)
  const rejectedMs = retentionToMs(settings.rejectedRetention);
  if (rejectedMs !== null && fs.existsSync(DIRS.rejected)) {
    const files = fs.readdirSync(DIRS.rejected);
    for (const f of files) {
      const full = path.join(DIRS.rejected, f);
      try {
        const stat = fs.statSync(full);
        if (now - stat.mtimeMs > rejectedMs) {
          fs.unlinkSync(full);
          deletedRejected++;
        }
      } catch {
        // ignore
      }
    }
  }

  // 3. Completed customer jobs cleanup
  const completedMs = retentionToMs(settings.completedRetention);
  if (completedMs !== null) {
    const db = await getDb();
    const cutoff = new Date(now - completedMs).toISOString();
    const stmt = db.prepare("SELECT id, public_job_id FROM jobs WHERE status IN ('COMPLETED', 'PUBLISHED') AND completed_at < ?");
    stmt.bind([cutoff]);
    while (stmt.step()) {
      const job = stmt.getAsObject() as { id: string; public_job_id: string };
      const jobDir = path.join(DIRS.jobs, job.public_job_id);
      if (fs.existsSync(jobDir)) {
        try {
          fs.rmSync(jobDir, { recursive: true, force: true });
          deletedCompleted++;
        } catch {
          // ignore
        }
      }
    }
    stmt.free();
  }

  // 4. Final documents cleanup
  const finalDocMs = retentionToMs(settings.finalDocRetention);
  if (finalDocMs !== null && fs.existsSync(DIRS.finalDocs)) {
    const files = fs.readdirSync(DIRS.finalDocs);
    for (const f of files) {
      const full = path.join(DIRS.finalDocs, f);
      try {
        const stat = fs.statSync(full);
        if (now - stat.mtimeMs > finalDocMs) {
          fs.unlinkSync(full);
          deletedFinalDocs++;
        }
      } catch {
        // ignore
      }
    }
  }

  const totalDeleted = deletedIncomplete + deletedRejected + deletedCompleted + deletedFinalDocs;
  if (totalDeleted > 0) {
    await addAuditLog(
      'INFO',
      'CLEANUP',
      `Automatic retention cleanup removed ${totalDeleted} expired item(s).`,
      JSON.stringify({ deletedIncomplete, deletedRejected, deletedCompleted, deletedFinalDocs })
    );
  }

  return {
    deletedIncomplete,
    deletedRejected,
    deletedCompleted,
    deletedFinalDocs,
  };
}

let cleanupInterval: NodeJS.Timeout | null = null;

export function startCleanupScheduler() {
  if (cleanupInterval) clearInterval(cleanupInterval);
  // Run once on startup after 10 seconds, then every 10 minutes
  setTimeout(() => runCleanupCycle().catch(console.error), 10000);
  cleanupInterval = setInterval(() => {
    runCleanupCycle().catch(console.error);
  }, 10 * 60 * 1000);
}

# AQ DIGITAL File Desk — Developer Documentation

## Architecture

The project is organized into clear decoupled layers:

```text
src/
  components/
    OperatorHeader.tsx       # Operator status bar & top navigation
    IncomingJobs.tsx         # Live jobs table with real-time status & actions
    CustomerConnectionView.tsx # Dual Wi-Fi & Customer URL QR generators
    PdfEditorModal.tsx       # Built-in PDF crop, text stamp & itemized charges studio
    JobHistoryView.tsx       # Multi-criteria job history, search & CSV exporter
    SettingsView.tsx         # Configuration manager for SSID, port, limits & retention
    DiagnosticsView.tsx      # System diagnostics, Phase 85 report & audit log
    CustomerPortal.tsx       # Clean, mobile-first customer phone upload interface
  types.ts                   # Domain TypeScript models

server/
  storage.ts                 # Dedicated directory structure & storage calculation
  db.ts                      # Embedded SQLite 3 database manager (sql.js)
  security.ts                # Magic bytes validation, filename sanitization & Defender scanner
  network.ts                 # Wi-Fi network detection & QR code generation
  pdf.ts                     # PDF cropping, text stamping & itemized charge calculations
  cleanup.ts                 # Retention policy scheduler (30m, 1h, 6h, 24h, 7d, 30d, Never)

server.ts                    # Full-Stack Express application with Vite middleware integration
```

## Database Schema (SQLite 3)

The SQLite database is persisted in `./AQ-DIGITAL/Config/aq_digital.sqlite`:
- `jobs`: Stores `id`, `public_job_id`, `secure_token`, `status`, `file_count`, `total_size`, timestamps, and audit notes.
- `files`: Stores `job_id`, original and safe filenames, size, MIME type, `signature_type`, `storage_state`, and `scan_status`.
- `final_documents`: Stores `job_id`, `generated_filename`, `file_size`, and `secure_document_token`.
- `charges`: Itemized service fees (`description`, `amount`).
- `settings`: Application configuration JSON.
- `audit_logs`: Immutable security and operation audit trail.

## Building and Compiling

Run the linter and compilation checks:
```bash
npm run lint
npm run build
```
The server bundle will compile into `dist/server.cjs` and the frontend into `dist/index.html`.

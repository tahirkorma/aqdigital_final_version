@echo off
title AQ DIGITAL - Option A Hotspot Configuration
color 0B
echo =====================================================================
echo    AQ DIGITAL - OPTION A: SINGLE-SCAN CAPTIVE HOTSPOT SETUP
echo =====================================================================
echo.
echo This script configures your Windows PC for Option A:
echo 1. Starts the isolated "AQ-DIGITAL" Wi-Fi Hotspot.
echo 2. Sets up Windows port-proxy to route port 80 probes to port 3000.
echo 3. Configures Windows Firewall for local mobile access.
echo.

net session >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [WARNING] Please run this batch script as Administrator!
    echo Right-click this file and choose "Run as administrator".
    echo.
    pause
    exit /b 1
)

echo [*] Step 1/4: Ensuring Hotspot DHCP Service (SharedAccess) is running...
sc config SharedAccess start= demand >nul 2>&1
net start SharedAccess >nul 2>&1
echo [OK] DHCP / Hotspot service verified.

echo.
echo [*] Step 2/4: Configuring Wi-Fi Hotspot (SSID: AQ-DIGITAL)...
netsh wlan set hostednetwork mode=allow ssid=AQ-DIGITAL key=12345678 >nul 2>&1
netsh wlan start hostednetwork
if %ERRORLEVEL% neq 0 (
    echo.
    echo [NOTE] If hostednetwork is not supported by your Wi-Fi 6 driver:
    echo Please turn on "Mobile Hotspot" in Windows Settings:
    echo 1. Open Windows Settings (Win + I) -^> Network ^& Internet -^> Mobile Hotspot
    echo 2. Click "Edit" -^> Set Network name to: AQ-DIGITAL, Password: 12345678
    echo 3. Toggle Mobile Hotspot to ON.
    echo.
)

echo.
echo [*] Step 3/4: Enabling Port 80 to Port 3000 redirection for Captive Portal...
netsh interface portproxy delete v4tov4 listenport=80 listenaddress=0.0.0.0 >nul 2>&1
netsh interface portproxy add v4tov4 listenport=80 listenaddress=0.0.0.0 connectport=3000 connectaddress=127.0.0.1
echo [OK] Windows port proxy active (Port 80 -> Port 3000).

echo.
echo [*] Step 4/4: Allowing ports 3000, 80, and DNS 53 in Windows Firewall...
netsh advfirewall firewall delete rule name="AQ DIGITAL File Desk Ingress" >nul 2>&1
netsh advfirewall firewall add rule name="AQ DIGITAL File Desk Ingress" dir=in action=allow protocol=TCP localport=3000,80 >nul 2>&1
netsh advfirewall firewall delete rule name="AQ DIGITAL DNS Ingress" >nul 2>&1
netsh advfirewall firewall add rule name="AQ DIGITAL DNS Ingress" dir=in action=allow protocol=UDP localport=53 >nul 2>&1
echo [OK] Windows Firewall rules configured.

echo.
echo =====================================================================
echo [SUCCESS] OPTION A HOTSPOT IS READY!
echo.
echo Customer Connection Info:
echo - Wi-Fi SSID:    AQ-DIGITAL
echo - Password:       12345678
echo - Direct Web URL: http://192.168.137.1:3000/upload
echo.
echo Instructions:
echo 1. On your PC Dashboard, open "Customer QR Code".
echo 2. Show the "Option A: Single Scan" QR code to the customer.
echo 3. The customer points camera and taps "Join".
echo 4. Upload desk automatically slides open on iOS CNA or Android!
echo 5. If phone didn't auto-open: customer can scan the Web URL QR or
echo    open http://192.168.137.1:3000/upload in Chrome/Safari.
echo =====================================================================
echo.
pause

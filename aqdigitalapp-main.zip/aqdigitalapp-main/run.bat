@echo off
title AQ DIGITAL File Desk - Local Server
color 0A
echo ===================================================
echo           AQ DIGITAL FILE DESK (PORTABLE)
echo ===================================================
echo.

where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Node.js is not installed on your PC!
    echo.
    echo Please install free Node.js from: https://nodejs.org
    echo Opening download page...
    start "" https://nodejs.org/en/download
    echo.
    pause
    exit /b 1
)

if not exist "dist\server.cjs" (
    echo [*] Preparing application bundle for first run...
    call npm run build
)

echo [*] Starting AQ DIGITAL File Desk on http://localhost:3000 ...
echo [*] Automatically opening your web browser...
echo [*] Press Ctrl+C in this window to stop the server (or run Stop-AQ-Digital.bat).
echo.

REM Automatically open browser after 1 second
start "" http://localhost:3000

REM Run the self-contained production bundle
set NODE_ENV=production
node dist/server.cjs

pause

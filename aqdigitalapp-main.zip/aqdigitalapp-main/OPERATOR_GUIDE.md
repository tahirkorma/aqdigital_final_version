# AQ DIGITAL File Desk — Operator Guide

Welcome to the operator guide for **AQ DIGITAL File Desk**.

---

## 1. Daily Shop Startup

1. Turn on the shop PC.
2. Launch **AQ DIGITAL File Desk** from the desktop shortcut.
3. Verify that the top bar displays:
   - **Hotspot**: `AQ-DIGITAL` (or your configured shop SSID)
   - **Status**: `ONLINE`
   - **Network**: `LOCAL ONLY` (Internet Isolation Active)
4. Ensure your printed QR display card is placed clearly on the customer service counter.

---

## 2. Assisting Walk-In Customers

1. Ask the customer to open their phone camera and point it at the desk QR card.
2. The phone prompts: **"Join AQ-DIGITAL Wi-Fi?"** -> Customer taps **Join**.
3. The customer phone loads the upload page:
   - Tap **"Select Files"** (choose PDFs, phone gallery images, or camera photos).
   - Tap **"Upload"**.
4. The customer sees the live progress bar and receives their **Job ID** (e.g. `AQD-20260921-0001`).
5. Instruct the customer: **"Please keep your browser page open while we process your typing/print work."**

---

## 3. Operator Workflow: Receiving & Processing

1. In the **Incoming Jobs** tab, the new job appears instantly.
2. Click **Files** to inspect the customer's uploaded documents, file sizes, and security scan status.
3. Click **Accept** to accept the job into processing.
4. If a file is malicious, invalid, or inappropriate:
   - Click **Reject** and choose a reason (e.g. "Unsupported file", "Malware detected").
   - The customer's phone page updates immediately with the reason.
5. If an upload is taking too long or the customer leaves:
   - Click **Terminate** to immediately stop and abort the transfer.

---

## 4. Returning Completed Documents to Customer

Once you complete work on an external portal (typing certificate, government form, or receipt):

1. Click **Return PDF** next to the customer's job.
2. Click **Select Portal PDF** to load your completed file.
3. Choose your workflow:
   - **Send Directly**: Sends the exact portal document without any changes.
   - **Edit & Send**:
     - Adjust **Crop** sliders to trim unwanted portal margins or header bars.
     - Add a custom **Shop Stamp** or reference text.
     - Add **Additional Charges** (e.g. Typing ₹50, Printing ₹20, Scanning ₹10) with automatic total calculation.
     - Check **"Stamp Charges Box onto Document"** to print the itemized receipt slip directly on the bottom of the document.
4. Click **Publish to Customer**.
5. The customer's waiting phone instantly rings/updates:
   - Displays **"YOUR DOCUMENT IS READY!"** with a green **Download Document** button.
   - Customer taps download and receives their finished PDF.

---

## 5. Pausing New Receiving

During busy shop peak hours:
- Click the **Pause Receiving** button in the top navigation bar.
- New uploads will be blocked with a clear message: *"Receiving paused temporarily. Please speak with shop operator."*
- Active in-progress jobs continue without interruption.

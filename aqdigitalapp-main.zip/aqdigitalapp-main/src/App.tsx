import React, { useState, useEffect, useRef, useCallback, Suspense } from 'react';
import { OperatorHeader } from './components/OperatorHeader';
import { CustomerPortal } from './components/CustomerPortal';
import {
  Job,
  NetworkStatus,
  ShopSettings,
  DashboardStats,
  StorageStatus
} from './types';
import { Smartphone, X, Inbox, Clock, CheckCircle2, ShieldAlert, Power } from 'lucide-react';

// Code-split operator heavy components to keep Customer Portal opening instantaneous
const IncomingJobs = React.lazy(() =>
  import('./components/IncomingJobs').then((m) => ({ default: m.IncomingJobs }))
);
const CustomerConnectionView = React.lazy(() =>
  import('./components/CustomerConnectionView').then((m) => ({ default: m.CustomerConnectionView }))
);
const JobHistoryView = React.lazy(() =>
  import('./components/JobHistoryView').then((m) => ({ default: m.JobHistoryView }))
);
const SettingsView = React.lazy(() =>
  import('./components/SettingsView').then((m) => ({ default: m.SettingsView }))
);
const DiagnosticsView = React.lazy(() =>
  import('./components/DiagnosticsView').then((m) => ({ default: m.DiagnosticsView }))
);
const PdfEditorModal = React.lazy(() =>
  import('./components/PdfEditorModal').then((m) => ({ default: m.PdfEditorModal }))
);

export default function App() {
  const isCustomerPath = typeof window !== 'undefined' && (
    window.location.pathname.startsWith('/upload') ||
    window.location.pathname.startsWith('/portal') ||
    window.location.search.includes('customer') ||
    window.location.hostname === 'aqdigital' ||
    (!window.location.pathname.startsWith('/operator') &&
      /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) &&
      window.location.hostname !== 'localhost' &&
      window.location.hostname !== '127.0.0.1')
  );

  const [viewMode, setViewMode] = useState<'OPERATOR' | 'CUSTOMER_FULLSCREEN'>(
    isCustomerPath ? 'CUSTOMER_FULLSCREEN' : 'OPERATOR'
  );
  const [activeTab, setActiveTab] = useState<string>('incoming');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [network, setNetwork] = useState<NetworkStatus | null>(null);
  const [settings, setSettings] = useState<ShopSettings | null>(null);
  const [receivingPaused, setReceivingPaused] = useState<boolean>(false);
  const [serverOnline, setServerOnline] = useState<boolean>(true);
  const [isAppExited, setIsAppExited] = useState<boolean>(false);

  // Modals
  const [activePdfJob, setActivePdfJob] = useState<Job | null>(null);
  const [historyDetailJob, setHistoryDetailJob] = useState<Job | null>(null);
  const [showPhoneSimulator, setShowPhoneSimulator] = useState<boolean>(false);

  const isRefreshingRef = useRef(false);

  // Listen to browser navigation / history changes
  useEffect(() => {
    const handleLocationChange = () => {
      const isCust = 
        window.location.pathname.startsWith('/upload') ||
        window.location.pathname.startsWith('/portal') ||
        window.location.search.includes('customer') ||
        window.location.hostname === 'aqdigital' ||
        (!window.location.pathname.startsWith('/operator') &&
          /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) &&
          window.location.hostname !== 'localhost' &&
          window.location.hostname !== '127.0.0.1');
      setViewMode(isCust ? 'CUSTOMER_FULLSCREEN' : 'OPERATOR');
    };
    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  // Compute active, reachable customer portal URL
  const effectiveCustomerUrl = React.useMemo(() => {
    if (typeof window !== 'undefined') {
      const isCloudOrWeb = window.location.hostname !== 'localhost' &&
        window.location.hostname !== '127.0.0.1' &&
        !window.location.hostname.startsWith('192.168.') &&
        window.location.hostname !== 'aqdigital';
      if (isCloudOrWeb) {
        return `${window.location.origin}/upload`;
      }
    }
    return network?.customerUrl || 'http://aqdigital/upload';
  }, [network?.customerUrl]);

  const effectiveNetwork = React.useMemo(() => {
    if (!network) return null;
    return {
      ...network,
      customerUrl: effectiveCustomerUrl,
    };
  }, [network, effectiveCustomerUrl]);

  // Robust, single-roundtrip data fetching with graceful offline handling
  const refreshAll = useCallback(async () => {
    if (isRefreshingRef.current) return;
    isRefreshingRef.current = true;

    try {
      // 1. Try unified overview endpoint
      const res = await fetch('/api/operator/overview', {
        headers: { Accept: 'application/json' },
        cache: 'no-store',
      });

      if (res.ok) {
        const data = await res.json();
        if (data.jobs) setJobs(data.jobs);
        if (data.stats) {
          setStats(data.stats);
          setReceivingPaused(data.stats.receivingPaused);
        }
        if (data.network) setNetwork(data.network);
        if (data.settings) setSettings(data.settings);
        setServerOnline(true);
        return;
      }

      // 2. Fallback: Individual endpoints with Promise.allSettled
      const [jobsRes, statsRes, netRes, settingsRes] = await Promise.allSettled([
        fetch('/api/operator/jobs'),
        fetch('/api/operator/stats'),
        fetch('/api/operator/network'),
        fetch('/api/operator/settings'),
      ]);

      if (jobsRes.status === 'fulfilled' && jobsRes.value.ok) {
        setJobs(await jobsRes.value.json());
      }
      if (statsRes.status === 'fulfilled' && statsRes.value.ok) {
        const s = await statsRes.value.json();
        setStats(s);
        setReceivingPaused(s.receivingPaused);
      }
      if (netRes.status === 'fulfilled' && netRes.value.ok) {
        setNetwork(await netRes.value.json());
      }
      if (settingsRes.status === 'fulfilled' && settingsRes.value.ok) {
        setSettings(await settingsRes.value.json());
      }
      setServerOnline(true);
    } catch (err) {
      // Transient network hiccup - quiet retry without triggering AI studio console error banner
      setServerOnline(false);
    } finally {
      isRefreshingRef.current = false;
    }
  }, []);

  useEffect(() => {
    // Only poll operator data if in OPERATOR view mode to avoid background network overhead for customers
    if (viewMode !== 'OPERATOR') return;

    refreshAll();
    const interval = setInterval(refreshAll, 3000);
    return () => clearInterval(interval);
  }, [refreshAll, viewMode]);

  const handleToggleReceiving = async () => {
    try {
      const res = await fetch('/api/operator/receiving/toggle', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setReceivingPaused(data.receivingPaused);
        refreshAll();
      }
    } catch (err) {
      console.warn('Failed to toggle receiving:', err);
    }
  };

  const handleAcceptJob = async (jobId: string) => {
    try {
      const res = await fetch(`/api/operator/jobs/${jobId}/accept`, { method: 'POST' });
      if (res.ok) refreshAll();
    } catch (err) {
      console.warn('Accept job error:', err);
    }
  };

  const handleRejectJob = async (jobId: string, reason: string) => {
    try {
      const res = await fetch(`/api/operator/jobs/${jobId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      if (res.ok) refreshAll();
    } catch (err) {
      console.warn('Reject job error:', err);
    }
  };

  const handleTerminateJob = async (jobId: string) => {
    try {
      const res = await fetch(`/api/operator/jobs/${jobId}/terminate`, { method: 'POST' });
      if (res.ok) refreshAll();
    } catch (err) {
      console.warn('Terminate job error:', err);
    }
  };

  const handleSaveSettings = async (updated: Partial<ShopSettings>) => {
    const res = await fetch('/api/operator/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to save settings');
    }
    await refreshAll();
  };

  const handleRunCleanup = async () => {
    const res = await fetch('/api/operator/cleanup/run', { method: 'POST' });
    if (!res.ok) throw new Error('Cleanup failed');
    await refreshAll();
  };

  const handleResetSettings = async () => {
    const res = await fetch('/api/operator/settings/reset', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to reset settings');
    const reset = await res.json();
    setSettings(reset);
    await refreshAll();
    return reset;
  };

  const handleExitApp = async () => {
    try {
      await fetch('/api/operator/shutdown', { method: 'POST' });
    } catch (e) {
      // Expected if server process terminates
    }
    setIsAppExited(true);
  };

  // If application was closed/exited by operator
  if (isAppExited) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center select-none font-sans">
        <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-5 text-red-500 shadow-2xl">
          <Power className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-black text-slate-100 mb-2 tracking-tight">AQ DIGITAL File Desk Closed</h1>
        <p className="text-sm text-slate-400 max-w-md mb-6 leading-relaxed">
          The background server process has been safely shut down and local desk receiving has stopped. You can now close this tab or window.
        </p>
        <button
          onClick={() => {
            setIsAppExited(false);
            window.location.reload();
          }}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition-colors shadow-xs"
        >
          Restart / Reconnect
        </button>
      </div>
    );
  }

  // If user toggled to Customer Fullscreen (Customer should never see Operator View button)
  if (viewMode === 'CUSTOMER_FULLSCREEN') {
    return (
      <div className="relative min-h-screen">
        {!isCustomerPath && (
          <div className="bg-slate-900 text-slate-200 px-4 py-2 text-xs flex items-center justify-between border-b border-slate-800 shadow-sm sticky top-0 z-50">
            <span className="font-semibold text-amber-400 flex items-center gap-1.5">
              <span>⚠️ Operator Testing Mode: Customer Upload Portal</span>
            </span>
            <button
              id="btn-return-operator-desk"
              onClick={() => setViewMode('OPERATOR')}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-xs transition-colors shadow-xs"
            >
              &larr; Return to Operator Desk
            </button>
          </div>
        )}
        <CustomerPortal />
      </div>
    );
  }

  const pendingCount = jobs.filter((j) =>
    ['NEW', 'UPLOADING', 'UPLOAD_COMPLETE', 'SCANNING', 'CLEAN', 'WAITING_ACCEPTANCE', 'ACCEPTED', 'PROCESSING'].includes(j.status)
  ).length;

  return (
    <div id="aq-digital-app" className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* Top Operator Header */}
      <OperatorHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        network={effectiveNetwork}
        receivingPaused={receivingPaused}
        onToggleReceiving={handleToggleReceiving}
        onOpenCustomerPreview={() => setShowPhoneSimulator(true)}
        storage={stats?.storage || null}
        pendingCount={pendingCount}
        onExitApp={handleExitApp}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* Today's KPI Metric Cards */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block">Today's Jobs</span>
              <span className="text-xl font-black text-slate-900 mt-1 block">
                {stats.todayJobsCount}
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block">Files Received</span>
              <span className="text-xl font-black text-blue-600 mt-1 block">
                {stats.filesReceivedCount}
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block">Pending Process</span>
              <span className="text-xl font-black text-amber-600 mt-1 block">
                {stats.pendingCount}
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block">Completed</span>
              <span className="text-xl font-black text-emerald-600 mt-1 block">
                {stats.completedCount}
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block">Rejected / Blocked</span>
              <span className="text-xl font-black text-red-600 mt-1 block">
                {stats.rejectedCount}
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block">Services Revenue</span>
              <span className="text-xl font-black text-slate-900 mt-1 block">
                ₹{stats.todayRevenue.toFixed(0)}
              </span>
            </div>
          </div>
        )}

        {/* Tab Views */}
        <Suspense fallback={
          <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-400 text-xs">
            Loading workspace...
          </div>
        }>
          {activeTab === 'incoming' && (
            <IncomingJobs
              jobs={jobs}
              onRefresh={refreshAll}
              onAccept={handleAcceptJob}
              onReject={handleRejectJob}
              onTerminate={handleTerminateJob}
              onOpenPdfStudio={(job) => setActivePdfJob(job)}
            />
          )}

          {activeTab === 'history' && (
            <JobHistoryView
              jobs={jobs}
              onOpenDetails={(job) => setHistoryDetailJob(job)}
              onClearHistory={refreshAll}
            />
          )}

          {activeTab === 'qr' && (
            <CustomerConnectionView
              network={effectiveNetwork}
              onOpenMobileView={() => setShowPhoneSimulator(true)}
            />
          )}

          {activeTab === 'pdf' && (
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-base text-slate-900">Return Document Studio</h3>
              <p className="text-xs text-slate-500">
                Select any active customer job below to import, crop, add charges, and publish their finished document.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-2">
                {jobs
                  .filter((j) => ['ACCEPTED', 'PROCESSING', 'CLEAN', 'PUBLISHED'].includes(j.status))
                  .map((job) => (
                    <div
                      key={job.id}
                      onClick={() => setActivePdfJob(job)}
                      className="p-4 rounded-xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/20 cursor-pointer transition-all shadow-xs"
                    >
                      <div className="flex justify-between items-start">
                        <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-sm">
                          {job.public_job_id}
                        </span>
                        <span className="text-[11px] font-semibold text-slate-500">
                          {job.status}
                        </span>
                      </div>
                      <p className="font-semibold text-xs text-slate-800 mt-2">
                        {job.customer_name || 'Walk-in Customer'}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {job.file_count} files • {new Date(job.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {activeTab === 'settings' && settings && (
            <SettingsView
              settings={settings}
              onSave={handleSaveSettings}
              onRunCleanup={handleRunCleanup}
              onResetDefaults={handleResetSettings}
            />
          )}

          {activeTab === 'diagnostics' && (
            <DiagnosticsView network={network} />
          )}
        </Suspense>
      </main>

      {/* PDF Return Studio Modal */}
      {activePdfJob && (
        <Suspense fallback={null}>
          <PdfEditorModal
            job={activePdfJob}
            onClose={() => setActivePdfJob(null)}
            onSuccess={() => {
              setActivePdfJob(null);
              refreshAll();
            }}
          />
        </Suspense>
      )}

      {/* Interactive Mobile Phone Simulator Modal */}
      {showPhoneSimulator && (
        <div id="modal-phone-simulator" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 p-3 rounded-[40px] shadow-2xl border-4 border-slate-700 w-full max-w-sm flex flex-col relative h-[85vh]">
            {/* Phone Speaker Notch */}
            <div className="w-24 h-4 bg-slate-800 rounded-full mx-auto mb-2 flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-slate-950"></span>
            </div>

            <button
              onClick={() => setShowPhoneSimulator(false)}
              className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center text-xs font-bold hover:bg-slate-700 shadow-md border border-slate-600"
              title="Close Phone Simulator"
            >
              ✕
            </button>

            {/* Embedded Customer View */}
            <div className="flex-1 rounded-[28px] overflow-hidden bg-slate-50 flex flex-col">
              <CustomerPortal />
            </div>

            {/* Home Indicator Bar */}
            <div className="w-32 h-1 bg-slate-600 rounded-full mx-auto mt-2.5"></div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="p-4 bg-white border-t border-slate-200 text-center text-xs text-slate-400">
        <p className="font-semibold text-slate-600">AQ DIGITAL File Desk • Production Release v1.0</p>
        <p className="text-[11px] text-slate-400 mt-0.5">
          Local Wi-Fi File Transfer & Return System • Secure Microsoft Defender Quarantine Workflow
        </p>
      </footer>
    </div>
  );
}

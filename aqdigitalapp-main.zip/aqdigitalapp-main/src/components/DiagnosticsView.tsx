import React, { useState, useEffect } from 'react';
import {
  Activity,
  ShieldCheck,
  ShieldAlert,
  Server,
  HardDrive,
  Cpu,
  Terminal,
  RefreshCw,
  AlertTriangle,
  FileCode,
  CheckCircle2
} from 'lucide-react';
import { AuditLog, EnvironmentReport, NetworkStatus } from '../types';

interface DiagnosticsViewProps {
  network: NetworkStatus | null;
}

export const DiagnosticsView: React.FC<DiagnosticsViewProps> = ({ network }) => {
  const [report, setReport] = useState<EnvironmentReport | null>(null);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [logFilter, setLogFilter] = useState<'ALL' | 'SECURITY' | 'WARN' | 'INFO'>('ALL');
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [envRes, logsRes] = await Promise.all([
        fetch('/api/operator/environment'),
        fetch('/api/operator/logs?limit=100'),
      ]);
      if (envRes.ok) setReport(await envRes.json());
      if (logsRes.ok) setLogs(await logsRes.json());
    } catch (err) {
      console.warn('Failed to load diagnostics:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredLogs = logs.filter((l) => {
    if (logFilter === 'ALL') return true;
    return l.level === logFilter;
  });

  return (
    <div id="diagnostics-view" className="space-y-6">
      {/* Environment Specification (Phase 85) */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Host Environment & Windows Diagnostics</h3>
              <p className="text-[11px] text-slate-500">System capabilities, packaging readiness & network isolation</p>
            </div>
          </div>

          <button
            onClick={fetchData}
            disabled={isLoading}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh Audit</span>
          </button>
        </div>

        {report ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Operating System</span>
              <span className="font-semibold text-slate-900">{report.os}</span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Architecture</span>
              <span className="font-semibold text-slate-900">{report.arch}</span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Node.js Runtime</span>
              <span className="font-semibold text-slate-900">{report.nodeVersion}</span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Python Version</span>
              <span className="font-semibold text-slate-900">{report.pythonVersion}</span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Defender Status</span>
              <span className={`font-bold ${report.isWindows ? 'text-emerald-700' : 'text-blue-700'}`}>
                {report.isWindows ? 'MpCmdRun.exe Ready' : 'Secure Quarantine Hold Mode'}
              </span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Internet Sharing (ICS)</span>
              <span className="font-bold text-emerald-700">
                {network?.internetSharingStatus || 'OFF'} (Isolated)
              </span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Windows Firewall</span>
              <span className="font-bold text-emerald-700">
                {network?.firewallStatus || 'PROTECTED'}
              </span>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[11px]">Free Disk Space</span>
              <span className="font-semibold text-slate-900">{report.diskFreeGb} GB free / {report.diskTotalGb} GB</span>
            </div>
          </div>
        ) : (
          <div className="py-6 text-center text-slate-400 text-xs">Loading environment diagnostics...</div>
        )}
      </div>

      {/* Audit Logs Table */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Terminal className="w-5 h-5 text-slate-700" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Security & Operational Audit Log</h3>
              <p className="text-[11px] text-slate-500">Immutable local records of uploads, scans, terminations & cleanups</p>
            </div>
          </div>

          <div className="flex items-center space-x-1 text-xs">
            {(['ALL', 'SECURITY', 'WARN', 'INFO'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLogFilter(lvl)}
                className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                  logFilter === lvl
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <div className="max-h-96 overflow-y-auto rounded-xl border border-slate-100 divide-y divide-slate-100 text-xs">
          {filteredLogs.length === 0 ? (
            <p className="p-6 text-center text-slate-400">No logs matching filter.</p>
          ) : (
            filteredLogs.map((log) => (
              <div key={log.id} className="p-3 hover:bg-slate-50/80 transition-colors flex items-start space-x-3">
                <span
                  className={`px-2 py-0.5 rounded-sm font-mono text-[10px] font-bold shrink-0 mt-0.5 ${
                    log.level === 'SECURITY'
                      ? 'bg-red-100 text-red-700 border border-red-200'
                      : log.level === 'WARN'
                      ? 'bg-amber-100 text-amber-800 border border-amber-200'
                      : 'bg-blue-50 text-blue-700 border border-blue-100'
                  }`}
                >
                  {log.level}
                </span>

                <div className="flex-1 overflow-hidden">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-slate-800">{log.category}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-slate-600 mt-0.5 break-words">{log.message}</p>
                  {log.details && (
                    <pre className="text-[10px] text-slate-500 bg-slate-50 p-1.5 rounded-sm mt-1 overflow-x-auto font-mono">
                      {log.details}
                    </pre>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

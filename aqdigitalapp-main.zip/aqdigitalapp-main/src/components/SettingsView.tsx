import React, { useState, useEffect } from 'react';
import {
  Save,
  Wifi,
  Shield,
  Trash2,
  HardDrive,
  Lock,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Copy,
  Check,
  Folder,
  Plus,
  X,
  FileCheck2,
  Database,
  RefreshCw
} from 'lucide-react';
import { ShopSettings, RetentionPeriod } from '../types';

interface SettingsViewProps {
  settings: ShopSettings;
  onSave: (updated: Partial<ShopSettings>) => Promise<void>;
  onRunCleanup: () => Promise<void>;
  onResetDefaults?: () => Promise<ShopSettings>;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onSave,
  onRunCleanup,
  onResetDefaults
}) => {
  const [formData, setFormData] = useState<ShopSettings>(settings);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [cleanupRunning, setCleanupRunning] = useState(false);
  const [cleanupResult, setCleanupResult] = useState<string | null>(null);

  // New file type input states
  const [newIncomingExt, setNewIncomingExt] = useState('');
  const [newReturnExt, setNewReturnExt] = useState('');

  // Storage paths info
  const [storagePaths, setStoragePaths] = useState<{
    jobs: string;
    quarantine: string;
    finalDocs: string;
    dbPath: string;
  }>({
    jobs: 'storage/jobs',
    quarantine: 'storage/quarantine',
    finalDocs: 'storage/final_docs',
    dbPath: 'storage/config/aq_digital.sqlite'
  });

  // Copy indicator
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Reset confirmation modal
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  // Keep the form state independent from the App-level 3-second refresh polling.
  // The parent refreshes `settings` periodically for live operator data; syncing
  // that prop back into this form on every refresh would overwrite values while
  // the operator is editing them (e.g. a password would jump back to its saved value).
  // The form is initialized from `settings` when this view mounts, and explicit
  // Save/Reset actions update the form state when appropriate.

  // Fetch live storage paths from overview
  useEffect(() => {
    fetch('/api/operator/overview')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.storagePaths) {
          setStoragePaths(data.storagePaths);
        }
      })
      .catch(() => {});
  }, []);

  const retentionOptions: RetentionPeriod[] = ['30m', '1h', '6h', '24h', '7d', '30d', 'Never'];

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSaveSuccess(false);

    // Validate
    if (formData.hotspotSsid.length < 2) {
      setErrorMessage('Hotspot SSID must be at least 2 characters.');
      return;
    }
    if (formData.hotspotPassword.length < 8) {
      setErrorMessage('Hotspot Password must be at least 8 characters (WPA2 standard).');
      return;
    }
    if (formData.serverPort < 1 || formData.serverPort > 65535) {
      setErrorMessage('Server Port must be between 1 and 65535.');
      return;
    }

    setIsSaving(true);
    try {
      await onSave(formData);
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      setIsSaving(false);
      setErrorMessage(err.message || 'Failed to save configuration');
    }
  };

  const handleManualCleanup = async () => {
    setCleanupRunning(true);
    setCleanupResult(null);
    try {
      await onRunCleanup();
      setCleanupResult('Cleanup completed successfully.');
    } catch (err: any) {
      setCleanupResult('Cleanup error: ' + err.message);
    } finally {
      setCleanupRunning(false);
    }
  };

  const handleConfirmReset = async () => {
    setIsResetting(true);
    setErrorMessage(null);
    try {
      if (onResetDefaults) {
        const resetData = await onResetDefaults();
        setFormData(resetData);
      } else {
        const res = await fetch('/api/operator/settings/reset', { method: 'POST' });
        if (!res.ok) throw new Error('Reset failed');
        const resetData = await res.json();
        setFormData(resetData);
      }
      setShowResetConfirm(false);
      setResetSuccess(true);
      setTimeout(() => setResetSuccess(false), 3500);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to reset settings to defaults');
    } finally {
      setIsResetting(false);
    }
  };

  // Add an incoming extension
  const handleAddIncomingExt = (extToAdd?: string) => {
    const raw = (extToAdd || newIncomingExt).trim().toLowerCase().replace(/^\./, '');
    if (!raw) return;
    const current = formData.allowedExtensions || [];
    if (!current.includes(raw)) {
      setFormData({
        ...formData,
        allowedExtensions: [...current, raw]
      });
    }
    if (!extToAdd) setNewIncomingExt('');
  };

  const handleRemoveIncomingExt = (ext: string) => {
    const current = formData.allowedExtensions || [];
    setFormData({
      ...formData,
      allowedExtensions: current.filter((e) => e !== ext)
    });
  };

  // Add a return document extension
  const handleAddReturnExt = (extToAdd?: string) => {
    const raw = (extToAdd || newReturnExt).trim().toLowerCase().replace(/^\./, '');
    if (!raw) return;
    const current = formData.allowedReturnExtensions || [];
    if (!current.includes(raw)) {
      setFormData({
        ...formData,
        allowedReturnExtensions: [...current, raw]
      });
    }
    if (!extToAdd) setNewReturnExt('');
  };

  const handleRemoveReturnExt = (ext: string) => {
    const current = formData.allowedReturnExtensions || [];
    setFormData({
      ...formData,
      allowedReturnExtensions: current.filter((e) => e !== ext)
    });
  };

  // Presets
  const addDocPreset = () => {
    ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'rtf', 'odt'].forEach((e) =>
      handleAddIncomingExt(e)
    );
  };

  const addImagePreset = () => {
    ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'tiff', 'gif', 'svg', 'heic'].forEach((e) =>
      handleAddIncomingExt(e)
    );
  };

  const addArchivePreset = () => {
    ['zip', 'rar', '7z', 'tar', 'gz'].forEach((e) => handleAddIncomingExt(e));
  };

  const addReturnImagesPreset = () => {
    ['pdf', 'jpg', 'jpeg', 'png', 'webp'].forEach((e) => handleAddReturnExt(e));
  };

  const hasNeverRetention =
    formData.incompleteRetention === 'Never' ||
    formData.rejectedRetention === 'Never' ||
    formData.completedRetention === 'Never' ||
    formData.finalDocRetention === 'Never';

  return (
    <div id="settings-view" className="max-w-4xl mx-auto space-y-6">
      {/* Header with Save & Reset Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900">Operator Configuration</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Hotspot network, storage paths, file type rules, security inspection, and cleanup retention.
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          {saveSuccess && (
            <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" /> Saved Successfully
            </span>
          )}
          {resetSuccess && (
            <span className="text-xs text-blue-600 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" /> Reset to Factory Defaults
            </span>
          )}

          {/* Reset to Default Button */}
          <button
            id="btn-reset-defaults"
            type="button"
            onClick={() => setShowResetConfirm(true)}
            className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200"
            title="Restore default factory settings"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Defaults</span>
          </button>

          {/* Save Button */}
          <button
            id="btn-save-settings"
            type="button"
            onClick={() => handleSave()}
            disabled={isSaving}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'Saving...' : 'Apply & Save Settings'}
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* STORAGE LOCATIONS ON DISK SECTION */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-slate-800 rounded-lg text-emerald-400">
              <Folder className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Local File Storage & Save Path</h3>
              <p className="text-[11px] text-slate-400">
                Choose where incoming customer files, return documents, and SQLite database are saved on this PC
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={async () => {
                try {
                  await fetch('/api/operator/open-folder', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ folderPath: storagePaths.jobs || formData.storagePath })
                  });
                } catch (e) {
                  // ignore
                }
              }}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-xs"
              title="Open current Jobs folder in Windows File Explorer"
            >
              <Folder className="w-3.5 h-3.5" />
              <span>Open Folder in Explorer</span>
            </button>
          </div>
        </div>

        {/* Change Storage Path Input & Presets */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <label className="text-xs font-bold text-slate-200 block">
                Custom Storage Directory Path:
              </label>
              <p className="text-[11px] text-slate-400">
                Leave blank for default app directory, or enter any custom folder on Windows (e.g. D:\AQ-DIGITAL)
              </p>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, storagePath: '' })}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-semibold transition-colors"
              >
                Default App Folder
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, storagePath: 'D:\\AQ-DIGITAL' })}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-semibold transition-colors"
              >
                D:\AQ-DIGITAL
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              id="input-storage-path"
              type="text"
              value={formData.storagePath || ''}
              onChange={(e) => setFormData({ ...formData, storagePath: e.target.value })}
              placeholder="e.g. D:\ShopFiles\AQ-DIGITAL or C:\Users\Shop\Documents\AQ-DIGITAL"
              className="flex-1 px-3 py-2 text-xs font-mono rounded-xl border border-slate-700 bg-slate-900 text-slate-100 focus:outline-hidden focus:border-blue-500"
            />
            <button
              type="button"
              onClick={() => handleSave()}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-colors shadow-xs shrink-0"
            >
              Apply Path
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {/* Customer Jobs Folder */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between gap-2">
            <div>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-300">Customer Jobs & Files:</span>
                <span className="text-[10px] text-emerald-400 font-mono">Incoming / Saved</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Each job creates its own subfolder containing all validated files.
              </p>
            </div>
            <div className="flex items-center justify-between gap-2 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800 font-mono text-[11px] text-emerald-300">
              <span className="truncate select-all" title={storagePaths.jobs}>
                {storagePaths.jobs}
              </span>
              <button
                type="button"
                onClick={() => handleCopy(storagePaths.jobs, 'jobs')}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-sans font-semibold shrink-0"
              >
                {copiedKey === 'jobs' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'jobs' ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          {/* Return Documents Folder */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between gap-2">
            <div>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-300">Final Returned Documents:</span>
                <span className="text-[10px] text-blue-400 font-mono">PDF & Images</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Completed work, edited PDFs, and images sent back to customers.
              </p>
            </div>
            <div className="flex items-center justify-between gap-2 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800 font-mono text-[11px] text-blue-300">
              <span className="truncate select-all" title={storagePaths.finalDocs}>
                {storagePaths.finalDocs}
              </span>
              <button
                type="button"
                onClick={() => handleCopy(storagePaths.finalDocs, 'finalDocs')}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-sans font-semibold shrink-0"
              >
                {copiedKey === 'finalDocs' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'finalDocs' ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          {/* Security Quarantine */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between gap-2">
            <div>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-300">Security Quarantine:</span>
                <span className="text-[10px] text-amber-400 font-mono">Isolated</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Temporary quarantine holding files during antivirus scanning.
              </p>
            </div>
            <div className="flex items-center justify-between gap-2 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800 font-mono text-[11px] text-amber-300">
              <span className="truncate select-all" title={storagePaths.quarantine}>
                {storagePaths.quarantine}
              </span>
              <button
                type="button"
                onClick={() => handleCopy(storagePaths.quarantine, 'quarantine')}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-sans font-semibold shrink-0"
              >
                {copiedKey === 'quarantine' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'quarantine' ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          {/* SQLite Database & Audit Logs */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between gap-2">
            <div>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-300">Database & Audit Log:</span>
                <span className="text-[10px] text-purple-400 font-mono">SQLite DB</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Persistent database containing all transactions, jobs, and settings.
              </p>
            </div>
            <div className="flex items-center justify-between gap-2 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800 font-mono text-[11px] text-purple-300">
              <span className="truncate select-all" title={storagePaths.dbPath}>
                {storagePaths.dbPath}
              </span>
              <button
                type="button"
                onClick={() => handleCopy(storagePaths.dbPath, 'dbPath')}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-sans font-semibold shrink-0"
              >
                {copiedKey === 'dbPath' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'dbPath' ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 1. CONFIGURABLE FILE TYPES (INCOMING & OUTGOING) */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <FileCheck2 className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Supported File Types (Incoming & Outgoing)</h3>
              <p className="text-[11px] text-slate-500">
                Add, customize, or remove allowed extensions. Add as many file types as you need at any time.
              </p>
            </div>
          </div>
        </div>

        {/* Incoming Allowed Extensions */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <label className="font-bold text-slate-800 text-xs block">
                Incoming Customer Upload File Types ({formData.allowedExtensions?.length || 0})
              </label>
              <p className="text-[11px] text-slate-500">
                Customers can only upload files matching these extensions.
              </p>
            </div>

            {/* Quick Presets */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] text-slate-400 font-semibold uppercase">Presets:</span>
              <button
                type="button"
                onClick={addDocPreset}
                className="px-2 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 text-[10px] font-semibold rounded-md border border-slate-200 transition-colors"
              >
                + Office/Docs
              </button>
              <button
                type="button"
                onClick={addImagePreset}
                className="px-2 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 text-[10px] font-semibold rounded-md border border-slate-200 transition-colors"
              >
                + Images
              </button>
              <button
                type="button"
                onClick={addArchivePreset}
                className="px-2 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 text-[10px] font-semibold rounded-md border border-slate-200 transition-colors"
              >
                + Archives
              </button>
            </div>
          </div>

          {/* Tag Cloud */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap gap-2 min-h-[52px] items-center">
            {formData.allowedExtensions && formData.allowedExtensions.length > 0 ? (
              formData.allowedExtensions.map((ext) => (
                <span
                  key={ext}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white text-slate-800 font-mono text-xs font-semibold rounded-lg border border-slate-200 shadow-2xs hover:border-slate-300"
                >
                  .{ext}
                  <button
                    type="button"
                    onClick={() => handleRemoveIncomingExt(ext)}
                    className="text-slate-400 hover:text-red-600 rounded-full p-0.5"
                    title={`Remove .${ext}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))
            ) : (
              <span className="text-xs text-slate-400 italic">No restrictions (all extensions permitted)</span>
            )}
          </div>

          {/* Add custom incoming extension */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:max-w-xs">
              <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-mono">.</span>
              <input
                id="input-new-incoming-ext"
                type="text"
                value={newIncomingExt}
                onChange={(e) => setNewIncomingExt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddIncomingExt();
                  }
                }}
                placeholder="e.g. psd, cdr, ai, epub, heic"
                className="w-full pl-6 pr-3 py-2 text-xs font-mono rounded-xl border border-slate-200 bg-white focus:outline-hidden focus:border-blue-500"
              />
            </div>
            <button
              type="button"
              onClick={() => handleAddIncomingExt()}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add File Type</span>
            </button>
          </div>
        </div>

        <hr className="border-slate-100" />

        {/* Outgoing / Return Document Extensions */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <label className="font-bold text-slate-800 text-xs block">
                Outgoing Return Document Formats ({formData.allowedReturnExtensions?.length || 0})
              </label>
              <p className="text-[11px] text-slate-500">
                Formats supported when sending finished work back to customer (PDF and image formats).
              </p>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={addReturnImagesPreset}
                className="px-2 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 text-[10px] font-semibold rounded-md border border-slate-200 transition-colors"
              >
                + PDF & Standard Images
              </button>
            </div>
          </div>

          {/* Tag Cloud */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap gap-2 min-h-[52px] items-center">
            {formData.allowedReturnExtensions && formData.allowedReturnExtensions.length > 0 ? (
              formData.allowedReturnExtensions.map((ext) => (
                <span
                  key={ext}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white text-emerald-800 font-mono text-xs font-semibold rounded-lg border border-emerald-200 shadow-2xs hover:border-emerald-300"
                >
                  .{ext}
                  <button
                    type="button"
                    onClick={() => handleRemoveReturnExt(ext)}
                    className="text-slate-400 hover:text-red-600 rounded-full p-0.5"
                    title={`Remove .${ext}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))
            ) : (
              <span className="text-xs text-slate-400 italic">Defaults: .pdf, .jpg, .png</span>
            )}
          </div>

          {/* Add custom return extension */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:max-w-xs">
              <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-mono">.</span>
              <input
                id="input-new-return-ext"
                type="text"
                value={newReturnExt}
                onChange={(e) => setNewReturnExt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddReturnExt();
                  }
                }}
                placeholder="e.g. webp, bmp, svg"
                className="w-full pl-6 pr-3 py-2 text-xs font-mono rounded-xl border border-slate-200 bg-white focus:outline-hidden focus:border-blue-500"
              />
            </div>
            <button
              type="button"
              onClick={() => handleAddReturnExt()}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Return Format</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Hotspot & Network Settings */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
          <Wifi className="w-5 h-5 text-blue-600" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">Wi-Fi Hotspot & Local Network</h3>
            <p className="text-[11px] text-slate-500">Configures the Windows AP and customer address</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Hotspot Name / SSID
            </label>
            <input
              id="input-hotspot-ssid"
              type="text"
              value={formData.hotspotSsid}
              onChange={(e) => setFormData({ ...formData, hotspotSsid: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-blue-500 bg-white"
              placeholder="e.g., AQ-DIGITAL"
              required
            />
            <p className="text-[11px] text-slate-400 mt-1">Changes the advertised network name</p>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Hotspot Wi-Fi Password
            </label>
            <input
              id="input-hotspot-password"
              type="text"
              value={formData.hotspotPassword}
              onChange={(e) => setFormData({ ...formData, hotspotPassword: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-blue-500 bg-white font-mono"
              placeholder="Minimum 8 characters"
              required
            />
            <p className="text-[11px] text-slate-400 mt-1">Embedded automatically into customer QR</p>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Customer Hostname / Domain
            </label>
            <input
              id="input-customer-hostname"
              type="text"
              value={formData.customerHostname}
              onChange={(e) => setFormData({ ...formData, customerHostname: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-blue-500 bg-white font-mono"
              placeholder="e.g., aqdigital or aqdesk"
              required
            />
            <p className="text-[11px] text-slate-400 mt-1">Local URL displayed to customers</p>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Local Server Port
            </label>
            <input
              id="input-server-port"
              type="number"
              value={formData.serverPort}
              onChange={(e) => setFormData({ ...formData, serverPort: Number(e.target.value) })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-blue-500 bg-white font-mono"
              min={1}
              max={65535}
              required
            />
            <p className="text-[11px] text-slate-400 mt-1">Port 3000</p>
          </div>
        </div>
      </div>

      {/* 3. Upload File Limits */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
          <HardDrive className="w-5 h-5 text-purple-600" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">Upload Limits & Quotas</h3>
            <p className="text-[11px] text-slate-500">Prevent customer devices from overloading memory</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Max Single File Size (MB)
            </label>
            <input
              type="number"
              value={formData.maxFileSizeMb}
              onChange={(e) => setFormData({ ...formData, maxFileSizeMb: Number(e.target.value) })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono"
              min={1}
              max={1000}
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Max Files per Job
            </label>
            <input
              type="number"
              value={formData.maxFilesPerJob}
              onChange={(e) => setFormData({ ...formData, maxFilesPerJob: Number(e.target.value) })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono"
              min={1}
              max={100}
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Max Total Job Size (MB)
            </label>
            <input
              type="number"
              value={formData.maxTotalJobSizeMb}
              onChange={(e) => setFormData({ ...formData, maxTotalJobSizeMb: Number(e.target.value) })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono"
              min={10}
              max={2000}
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Auto-Cancel Inactivity Timeout
            </label>
            <input
              type="number"
              value={formData.autoRejectMinutes ?? 0}
              onChange={(e) => setFormData({ ...formData, autoRejectMinutes: Number(e.target.value) })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono"
              min={0}
              max={120}
            />
            <p className="text-[10px] text-slate-400 mt-0.5">0 = Keep indefinitely (Recommended)</p>
          </div>
        </div>
      </div>

      {/* 4. Security & Defender */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
          <Shield className="w-5 h-5 text-emerald-600" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">Security & Threat Inspection</h3>
            <p className="text-[11px] text-slate-500">Antivirus scanning and dangerous type filtering</p>
          </div>
        </div>

        <div className="space-y-3 text-xs">
          <label className="flex items-center space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.requireDefenderScan}
              onChange={(e) => setFormData({ ...formData, requireDefenderScan: e.target.checked })}
              className="rounded-sm text-blue-600 w-4 h-4"
            />
            <div>
              <span className="font-bold text-slate-800 block">Require Microsoft Defender Scan</span>
              <span className="text-slate-500 text-[11px]">
                Scans every completed upload through Windows Defender before making files available.
              </span>
            </div>
          </label>

          <label className="flex items-center space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.blockDangerousTypes}
              onChange={(e) => setFormData({ ...formData, blockDangerousTypes: e.target.checked })}
              className="rounded-sm text-blue-600 w-4 h-4"
            />
            <div>
              <span className="font-bold text-slate-800 block">Block Executables & Scripts</span>
              <span className="text-slate-500 text-[11px]">
                Strictly rejects .exe, .bat, .cmd, .ps1, .vbs, .msi, .dll (and inspects binary MZ headers).
              </span>
            </div>
          </label>

          <label className="flex items-center space-x-3 p-3 bg-amber-50/50 rounded-xl border border-amber-200 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.allowEmergencyBypass}
              onChange={(e) => setFormData({ ...formData, allowEmergencyBypass: e.target.checked })}
              className="rounded-sm text-amber-600 w-4 h-4"
            />
            <div>
              <span className="font-bold text-amber-900 block">Allow Emergency Antivirus Bypass</span>
              <span className="text-amber-800 text-[11px]">
                Allows proceeding if Microsoft Defender service is temporarily unreachable (Non-Windows dev fallback).
              </span>
            </div>
          </label>
        </div>
      </div>

      {/* 5. Automatic Cleanup & Retention */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Trash2 className="w-5 h-5 text-red-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Storage Retention & Cleanup</h3>
              <p className="text-[11px] text-slate-500">Automatically prune stale files after configured periods</p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleManualCleanup}
            disabled={cleanupRunning}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg flex items-center gap-1 transition-colors"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${cleanupRunning ? 'animate-spin' : ''}`} />
            {cleanupRunning ? 'Cleaning...' : 'Run Cleanup Now'}
          </button>
        </div>

        {cleanupResult && (
          <div className="p-3 bg-blue-50 text-blue-800 text-xs rounded-xl border border-blue-100">
            {cleanupResult}
          </div>
        )}

        {hasNeverRetention && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Automatic deletion is disabled for one or more categories ("Never"). Storage may fill over time.
            </span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Incomplete Transfers Retention
            </label>
            <select
              value={formData.incompleteRetention}
              onChange={(e) => setFormData({ ...formData, incompleteRetention: e.target.value as any })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
            >
              {retentionOptions.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Rejected Uploads Retention
            </label>
            <select
              value={formData.rejectedRetention}
              onChange={(e) => setFormData({ ...formData, rejectedRetention: e.target.value as any })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
            >
              {retentionOptions.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Completed Customer Files Retention
            </label>
            <select
              value={formData.completedRetention}
              onChange={(e) => setFormData({ ...formData, completedRetention: e.target.value as any })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
            >
              {retentionOptions.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Final Return Documents Retention
            </label>
            <select
              value={formData.finalDocRetention}
              onChange={(e) => setFormData({ ...formData, finalDocRetention: e.target.value as any })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
            >
              {retentionOptions.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 6. Windows Startup & System */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
          <Lock className="w-5 h-5 text-slate-700" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">Application & Windows Startup</h3>
            <p className="text-[11px] text-slate-500">Windows startup registry and operator controls</p>
          </div>
        </div>

        <div className="space-y-3 text-xs">
          <label className="flex items-center space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.startWithWindows}
              onChange={(e) => setFormData({ ...formData, startWithWindows: e.target.checked })}
              className="rounded-sm text-blue-600 w-4 h-4"
            />
            <div>
              <span className="font-bold text-slate-800 block">Start AQ DIGITAL with Windows</span>
              <span className="text-slate-500 text-[11px]">
                Automatically launches file desk server and tray icon when the PC boots.
              </span>
            </div>
          </label>
        </div>
      </div>

      {/* RESET CONFIRMATION MODAL */}
      {showResetConfirm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-amber-100 text-amber-700 rounded-xl">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Reset to Factory Defaults?</h3>
                <p className="text-xs text-slate-500">This will restore all default operator configurations.</p>
              </div>
            </div>

            <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1">
              <p className="font-semibold">The following will be reset:</p>
              <ul className="list-disc pl-4 text-[11px] text-amber-800 space-y-0.5">
                <li>Hotspot SSID back to <strong>AQ-DIGITAL</strong> & password to default</li>
                <li>Incoming allowed file extensions (Office, PDF, Images, Archives)</li>
                <li>Return document formats (PDF, JPG, PNG, WEBP)</li>
                <li>Default upload size limits and retention rules</li>
              </ul>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                disabled={isResetting}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReset}
                disabled={isResetting}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs flex items-center gap-1.5"
              >
                {isResetting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
                <span>{isResetting ? 'Resetting...' : 'Yes, Reset to Defaults'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

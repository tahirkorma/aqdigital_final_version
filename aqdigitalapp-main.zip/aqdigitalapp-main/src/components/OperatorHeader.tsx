import React, { useState } from 'react';
import {
  Wifi,
  ShieldCheck,
  Pause,
  Play,
  HardDrive,
  QrCode,
  Inbox,
  History,
  Settings as SettingsIcon,
  Activity,
  FileCheck2,
  Smartphone,
  LogOut,
  Power,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import { NetworkStatus, StorageStatus } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  network: NetworkStatus | null;
  receivingPaused: boolean;
  onToggleReceiving: () => void;
  onOpenCustomerPreview: () => void;
  storage: StorageStatus | null;
  pendingCount: number;
  onExitApp?: () => void;
}

export const OperatorHeader: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  network,
  receivingPaused,
  onToggleReceiving,
  onOpenCustomerPreview,
  storage,
  pendingCount,
  onExitApp
}) => {
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  const formatGb = (bytes: number) => {
    return (bytes / (1024 * 1024 * 1024)).toFixed(1);
  };

  const handleConfirmExit = async () => {
    setIsExiting(true);
    if (onExitApp) {
      await onExitApp();
    } else {
      try {
        await fetch('/api/operator/shutdown', { method: 'POST' });
      } catch (e) {
        // expected if server closes
      }
    }
    setShowExitConfirm(false);
  };

  return (
    <header id="operator-header" className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      {/* Top Status Bar */}
      <div className="px-6 py-2.5 bg-slate-950 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Left: Brand & Hotspot Info */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></span>
            <span className="font-bold text-white tracking-wide">AQ DIGITAL</span>
            <span className="text-slate-400 font-medium">| File Desk</span>
          </div>

          <div className="hidden sm:flex items-center space-x-2 text-slate-300">
            <Wifi className="w-3.5 h-3.5 text-blue-400" />
            <span>Hotspot:</span>
            <span className="font-mono text-white bg-slate-800 px-2 py-0.5 rounded-sm border border-slate-700">
              {network?.hotspotSsid || 'AQ-DIGITAL'}
            </span>
          </div>

          <div className="hidden md:flex items-center space-x-1.5 text-slate-300">
            <span>URL:</span>
            <a
              href={network?.customerUrl || '/upload'}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-mono text-emerald-400 hover:text-emerald-300 bg-slate-800 hover:bg-slate-750 px-2 py-0.5 rounded-sm border border-slate-700 transition-colors underline decoration-dotted"
              title="Click to open customer upload portal in a new tab"
            >
              <span>{network?.customerUrl || 'http://aqdigital/upload'}</span>
              <ExternalLink className="w-3 h-3 text-emerald-400 shrink-0" />
            </a>
          </div>
        </div>

        {/* Right: Security, Storage & Quick Actions */}
        <div className="flex items-center space-x-2">
          {/* Isolation pill */}
          <div
            className={`flex items-center space-x-1 px-2 py-0.5 rounded-full font-medium text-[11px] ${
              network?.customerNetworkStatus === 'LOCAL ONLY'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                : 'bg-amber-950 text-amber-300 border border-amber-800'
            }`}
            title="Customer phones cannot access the PC Internet connection"
          >
            <ShieldCheck className="w-3 h-3" />
            <span>{network?.customerNetworkStatus || 'LOCAL ONLY'}</span>
          </div>

          {/* Storage summary */}
          {storage && (
            <div
              className={`hidden lg:flex items-center space-x-1.5 text-slate-300 px-2 py-0.5 rounded-sm text-[11px] ${
                storage.status === 'CRITICAL'
                  ? 'bg-red-950 text-red-300 border border-red-800 font-bold'
                  : storage.status === 'WARNING'
                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                  : ''
              }`}
            >
              <HardDrive className="w-3 h-3 text-slate-400" />
              <span>Storage: {formatGb(storage.freeBytes)} GB free ({100 - storage.usedPercent}%)</span>
            </div>
          )}

          {/* Pause / Resume Receiving button */}
          <button
            id="btn-operator-toggle-pause"
            onClick={onToggleReceiving}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-colors shadow-xs ${
              receivingPaused
                ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold animate-pulse'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
            }`}
          >
            {receivingPaused ? (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>RECEIVING PAUSED</span>
              </>
            ) : (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause Receiving</span>
              </>
            )}
          </button>

          {/* Open Customer Upload Page in New Tab */}
          <a
            id="btn-operator-open-customer-tab"
            href={network?.customerUrl || '/upload'}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs bg-emerald-700 hover:bg-emerald-600 text-white font-medium transition-colors shadow-xs"
            title="Open customer upload page directly in a new browser tab"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Open Customer Page</span>
          </a>

          {/* Customer View Test Switcher */}
          <button
            id="btn-operator-customer-preview"
            onClick={onOpenCustomerPreview}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs bg-blue-600 hover:bg-blue-500 text-white font-medium transition-colors"
            title="Open phone customer test view (for operator testing only)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Phone Simulator</span>
          </button>

          {/* Exit / Log Out Button */}
          <button
            id="btn-exit-app"
            type="button"
            onClick={() => setShowExitConfirm(true)}
            className="flex items-center space-x-1.5 px-3 py-1 rounded-md text-xs font-semibold bg-red-900/60 hover:bg-red-800 text-red-100 hover:text-white border border-red-700/80 transition-colors shadow-xs"
            title="Exit and close application"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Exit / Close App</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="px-6 py-2 flex items-center justify-between">
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-1">
          <button
            id="tab-incoming-jobs"
            onClick={() => setActiveTab('incoming')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'incoming'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Inbox className="w-4 h-4" />
            <span>Incoming Jobs</span>
            {pendingCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 bg-white text-blue-700 text-[11px] font-extrabold rounded-full">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            id="tab-job-history"
            onClick={() => setActiveTab('history')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'history'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Job History</span>
          </button>

          <button
            id="tab-customer-qr"
            onClick={() => setActiveTab('qr')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'qr'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Customer QR & Wi-Fi</span>
          </button>

          <button
            id="tab-pdf-return"
            onClick={() => setActiveTab('pdf')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'pdf'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Return Document Studio</span>
          </button>

          <button
            id="tab-settings"
            onClick={() => setActiveTab('settings')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'settings'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <SettingsIcon className="w-4 h-4" />
            <span>Settings</span>
          </button>

          <button
            id="tab-diagnostics"
            onClick={() => setActiveTab('diagnostics')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'diagnostics'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Security & Logs</span>
          </button>
        </nav>
      </div>

      {/* EXIT / LOGOUT CONFIRMATION MODAL */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-red-100 text-red-600 rounded-xl">
                <Power className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Close Application & Exit?</h3>
                <p className="text-xs text-slate-500">Shut down the AQ DIGITAL local server desk.</p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1.5">
              <p>
                Closing the app will terminate active customer receiving sessions and safely shut down the background HTTP service.
              </p>
              <p className="text-[11px] text-slate-400">
                You can start it again anytime via your desktop shortcut or Windows startup.
              </p>
            </div>

            <div className="flex items-center justify-end space-x-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowExitConfirm(false)}
                disabled={isExiting}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-exit"
                onClick={handleConfirmExit}
                disabled={isExiting}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <Power className="w-3.5 h-3.5" />
                <span>{isExiting ? 'Shutting down...' : 'Yes, Exit App'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

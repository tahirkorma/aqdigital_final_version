' =========================================================================
'  AQ DIGITAL File Desk - One-Click Silent Launcher (No Command Prompt)
'  Starts production server and automatically opens http://localhost:3000
' =========================================================================

Option Explicit
Dim WshShell, fso, ScriptDir, ServerScript, NodeCmd, Command, i, isReady, logDir

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Current directory where the script is located
ScriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Determine user-writable data directory (%LOCALAPPDATA%\AQ-DIGITAL)
Dim localAppData, dataDir, logFile
localAppData = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%")
If localAppData = "%LOCALAPPDATA%" Or localAppData = "" Then
    dataDir = ScriptDir & "\AQ-DIGITAL"
Else
    dataDir = localAppData & "\AQ-DIGITAL"
End If

' Ensure Logs folder exists in user-writable directory
logDir = dataDir & "\Logs"
CreateFolderRecursive logDir
logFile = logDir & "\server_output.log"

' 1. Locate Node.js executable
NodeCmd = ""
If FileExists("C:\Program Files\nodejs\node.exe") Then
    NodeCmd = """C:\Program Files\nodejs\node.exe"""
ElseIf FileExists("C:\Program Files (x86)\nodejs\node.exe") Then
    NodeCmd = """C:\Program Files (x86)\nodejs\node.exe"""
Else
    ' Check PATH
    On Error Resume Next
    Dim oExec
    Set oExec = WshShell.Exec("node -v")
    If Err.Number = 0 Then
        NodeCmd = "node"
    End If
    On Error GoTo 0
End If

If NodeCmd = "" Then
    Dim answer
    answer = MsgBox("Node.js was not detected on this PC." & vbCrLf & vbCrLf & _
                    "AQ DIGITAL File Desk requires Node.js to run locally." & vbCrLf & vbCrLf & _
                    "Click [Yes] to open the official free Node.js download page.", _
                    vbYesNo + vbInformation + vbSystemModal, "AQ DIGITAL - Node.js Required")
    If answer = vbYes Then
        WshShell.Run "https://nodejs.org/en/download"
    End If
    WScript.Quit 1
End If

' 2. Verify that dist\server.cjs exists
ServerScript = ScriptDir & "\dist\server.cjs"
If Not fso.FileExists(ServerScript) Then
    MsgBox "Production server bundle not found:" & vbCrLf & _
           ServerScript & vbCrLf & vbCrLf & _
           "Please run 'Install-Desktop-App.bat' or 'npm run build' first.", _
           vbCritical + vbSystemModal, "AQ DIGITAL - Missing Bundle"
    WScript.Quit 1
End If

' 3. Check if server is ALREADY running on port 3000
If CheckServerRunning() Then
    ' Already running: simply bring up browser immediately!
    WshShell.Run "http://localhost:3000"
    WScript.Quit 0
End If

' 4. Launch production server silently in background (0 = hidden window)
Command = "cmd.exe /c cd /d """ & ScriptDir & """ && set NODE_ENV=production && " & NodeCmd & " dist\server.cjs >> """ & logFile & """ 2>&1"
WshShell.Run Command, 0, False

' 5. Wait for the server to be ready on port 3000 (poll health endpoint up to 10s)
isReady = False
For i = 1 To 25
    WScript.Sleep 400
    If CheckServerRunning() Then
        isReady = True
        Exit For
    End If
Next

' 6. Automatically open browser to localhost:3000
WshShell.Run "http://localhost:3000"

' Helper function: tests if port 3000 responds to HTTP
Function CheckServerRunning()
    On Error Resume Next
    Dim http
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    If Err.Number <> 0 Then
        Set http = CreateObject("MSXML2.ServerXMLHTTP")
    End If
    http.Open "GET", "http://127.0.0.1:3000/api/health", False
    http.setTimeouts 500, 500, 500, 500
    http.Send
    If Err.Number = 0 Then
        If http.Status = 200 Then
            CheckServerRunning = True
            Exit Function
        End If
    End If
    CheckServerRunning = False
    On Error GoTo 0
End Function

Function FileExists(filePath)
    On Error Resume Next
    FileExists = fso.FileExists(filePath)
    On Error GoTo 0
End Function

Sub CreateFolderRecursive(fPath)
    On Error Resume Next
    If Not fso.FolderExists(fPath) Then
        Dim parent
        parent = fso.GetParentFolderName(fPath)
        If parent <> "" And Not fso.FolderExists(parent) Then
            CreateFolderRecursive parent
        End If
        fso.CreateFolder fPath
    End If
    On Error GoTo 0
End Sub

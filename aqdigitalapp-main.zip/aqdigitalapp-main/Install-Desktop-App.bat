@echo off
setlocal enabledelayedexpansion
title Install AQ DIGITAL Desktop App
echo ===================================================
echo     AQ DIGITAL File Desk - Desktop Setup
echo ===================================================
echo.

set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "TARGET=%SCRIPT_DIR%\Start-AQ-Digital.vbs"
set "WORKINGDIR=%SCRIPT_DIR%"
set "DESKTOP=%USERPROFILE%\Desktop"

REM 1. Verify build bundle exists
if not exist "%SCRIPT_DIR%\dist\server.cjs" (
    echo [*] Preparing production bundle for first run...
    where npm >nul 2>nul
    if !ERRORLEVEL! equ 0 (
        call npm run build
    ) else (
        echo [WARNING] npm was not found. Please ensure dist\server.cjs is present.
    )
)

echo [*] Creating Desktop shortcut: "AQ DIGITAL File Desk"...

REM Create Desktop shortcut with proper path and icon
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$s = $ws.CreateShortcut('%DESKTOP%\AQ DIGITAL File Desk.lnk'); " ^
  "$s.TargetPath = 'wscript.exe'; " ^
  "$s.Arguments = '\"%TARGET%\"'; " ^
  "$s.WorkingDirectory = '%WORKINGDIR%'; " ^
  "$s.IconLocation = 'C:\Windows\System32\shell32.dll,220'; " ^
  "$s.Description = 'AQ DIGITAL File Desk - Local File Receiving Desk'; " ^
  "$s.Save()"

if exist "%DESKTOP%\AQ DIGITAL File Desk.lnk" (
    echo [SUCCESS] "AQ DIGITAL File Desk" shortcut created on your Desktop!
    echo.
    echo [*] Starting AQ DIGITAL File Desk and opening http://localhost:3000 ...
    start "" wscript.exe "%TARGET%"
) else (
    echo [NOTICE] Desktop shortcut creation skipped. Running application directly...
    start "" wscript.exe "%TARGET%"
)

echo.
timeout /t 3 >nul

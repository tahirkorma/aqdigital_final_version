@echo off
REM AQ DIGITAL File Desk - Windows Batch Build Script
echo ==========================================
echo   AQ DIGITAL File Desk - Windows Build
echo ==========================================

echo [1/3] Building Vite client and Express server bundle...
call npm run build:standalone
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Build failed!
    exit /b %ERRORLEVEL%
)

echo [2/3] Verifying bundle output...
if exist "dist\server.cjs" (
    echo [OK] dist\server.cjs created successfully.
) else (
    echo [ERROR] dist\server.cjs not found!
    exit /b 1
)

echo [3/3] Checking for Inno Setup compiler...
set ISCC="C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if not exist %ISCC% set ISCC="C:\Program Files\Inno Setup 6\ISCC.exe"

if exist %ISCC% (
    %ISCC% installer\aq_digital_setup.iss
    echo.
    echo =========================================================
    echo [SUCCESS] Windows Installer created at:
    echo   dist_installer\AQ-Digital-Setup.exe
    echo =========================================================
) else (
    echo [INFO] Inno Setup 6 compiler not detected.
    echo        The application is already ready to run!
    echo        Just double-click 'Start-AQ-Digital.vbs' or 'Install-Desktop-App.bat'.
)

echo ==========================================
echo   Finished!
echo ==========================================

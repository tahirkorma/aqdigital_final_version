import fs from 'fs';
import path from 'path';

export const BASE_DATA_DIR = process.env.AQ_DATA_DIR || path.join(process.cwd(), 'AQ-DIGITAL');

export const DIRS = {
  root: BASE_DATA_DIR,
  jobs: path.join(BASE_DATA_DIR, 'Jobs'),
  incoming: path.join(BASE_DATA_DIR, 'Incoming'),
  quarantine: path.join(BASE_DATA_DIR, 'Quarantine'),
  rejected: path.join(BASE_DATA_DIR, 'Rejected'),
  finalDocs: path.join(BASE_DATA_DIR, 'FinalDocuments'),
  logs: path.join(BASE_DATA_DIR, 'Logs'),
  config: path.join(BASE_DATA_DIR, 'Config'),
  temp: path.join(BASE_DATA_DIR, 'Temp'),
  backups: path.join(BASE_DATA_DIR, 'Backups'),
};

export function initStorageDirectories() {
  Object.values(DIRS).forEach((dir) => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });
}

export function getStorageUsage(warningPercent = 80, criticalPercent = 90) {
  try {
    let totalBytes = 500 * 1024 * 1024 * 1024; // 500 GB fallback
    let freeBytes = 450 * 1024 * 1024 * 1024;
    let usedBytes = 0;

    // Measure actual usage of AQ-DIGITAL directory
    function getDirSize(dirPath: string): number {
      let size = 0;
      if (!fs.existsSync(dirPath)) return 0;
      const files = fs.readdirSync(dirPath);
      for (const file of files) {
        const full = path.join(dirPath, file);
        try {
          const stat = fs.statSync(full);
          if (stat.isDirectory()) {
            size += getDirSize(full);
          } else {
            size += stat.size;
          }
        } catch {
          // ignore unreadable
        }
      }
      return size;
    }

    usedBytes = getDirSize(BASE_DATA_DIR);

    // If on linux or node supports statfs
    if (typeof fs.statfsSync === 'function') {
      try {
        const stats = fs.statfsSync(BASE_DATA_DIR);
        totalBytes = stats.bsize * stats.blocks;
        freeBytes = stats.bsize * stats.bavail;
      } catch {
        // use defaults
      }
    }

    const usedPercent = totalBytes > 0 ? Math.round(((totalBytes - freeBytes) / totalBytes) * 100) : 10;
    let status: 'OK' | 'WARNING' | 'CRITICAL' = 'OK';
    if (usedPercent >= criticalPercent) {
      status = 'CRITICAL';
    } else if (usedPercent >= warningPercent) {
      status = 'WARNING';
    }

    return {
      totalBytes,
      usedBytes,
      freeBytes,
      usedPercent,
      status,
    };
  } catch (err) {
    return {
      totalBytes: 500 * 1024 * 1024 * 1024,
      usedBytes: 1024 * 1024 * 10,
      freeBytes: 490 * 1024 * 1024 * 1024,
      usedPercent: 2,
      status: 'OK' as const,
    };
  }
}

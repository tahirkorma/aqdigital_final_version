import fs from 'fs';
import path from 'path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { DIRS } from './storage';
import { ChargeItem } from '../src/types';

export interface PdfEditOptions {
  crop?: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  customTexts?: Array<{
    text: string;
    x: number;
    y: number;
    size: number;
    color?: string; // hex e.g. #000000 or #e11d48
  }>;
  charges?: Array<{
    description: string;
    amount: number;
  }>;
  showChargesBox?: boolean;
}

export async function processAndSaveFinalPdf(
  originalPdfPath: string,
  publicJobId: string,
  options?: PdfEditOptions
): Promise<{ finalFilePath: string; filename: string; size: number }> {
  if (!fs.existsSync(originalPdfPath)) {
    throw new Error('Original portal PDF not found at ' + originalPdfPath);
  }

  const originalBytes = fs.readFileSync(originalPdfPath);
  const pdfDoc = await PDFDocument.load(originalBytes);
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const pages = pdfDoc.getPages();

  // If crop is specified, adjust media box of all pages
  if (options?.crop) {
    const { top, bottom, left, right } = options.crop;
    for (const page of pages) {
      const { width, height } = page.getSize();
      const newX = Math.max(0, left);
      const newY = Math.max(0, bottom);
      const newWidth = Math.max(100, width - left - right);
      const newHeight = Math.max(100, height - top - bottom);
      page.setCropBox(newX, newY, newWidth, newHeight);
    }
  }

  // If custom text annotations provided
  if (options?.customTexts && options.customTexts.length > 0) {
    const targetPage = pages[0]; // Apply to first page or active page
    for (const item of options.customTexts) {
      targetPage.drawText(item.text, {
        x: item.x,
        y: item.y,
        size: item.size || 12,
        font: helveticaFont,
        color: rgb(0.1, 0.1, 0.1),
      });
    }
  }

  // If itemized additional charges block requested
  if (options?.showChargesBox && options.charges && options.charges.length > 0) {
    const targetPage = pages[0];
    const { width, height } = targetPage.getSize();

    // Draw itemized charges box at bottom right
    const boxWidth = 220;
    const rowHeight = 16;
    const headerHeight = 22;
    const totalRowHeight = 20;
    const boxHeight = headerHeight + options.charges.length * rowHeight + totalRowHeight + 10;
    const boxX = width - boxWidth - 30;
    const boxY = 40;

    // Background rectangle
    targetPage.drawRectangle({
      x: boxX,
      y: boxY,
      width: boxWidth,
      height: boxHeight,
      color: rgb(0.97, 0.98, 0.99),
      borderColor: rgb(0.2, 0.3, 0.4),
      borderWidth: 1,
    });

    // Header
    targetPage.drawText('AQ DIGITAL CHARGES', {
      x: boxX + 10,
      y: boxY + boxHeight - 16,
      size: 10,
      font: helveticaBold,
      color: rgb(0.06, 0.09, 0.16),
    });

    let currentY = boxY + boxHeight - 34;
    let total = 0;

    for (const charge of options.charges) {
      targetPage.drawText(charge.description, {
        x: boxX + 10,
        y: currentY,
        size: 9,
        font: helveticaFont,
        color: rgb(0.2, 0.25, 0.3),
      });

      const amountStr = `INR ${charge.amount.toFixed(2)}`;
      targetPage.drawText(amountStr, {
        x: boxX + boxWidth - 65,
        y: currentY,
        size: 9,
        font: helveticaFont,
        color: rgb(0.1, 0.1, 0.1),
      });

      total += charge.amount;
      currentY -= rowHeight;
    }

    // Divider
    targetPage.drawLine({
      start: { x: boxX + 10, y: currentY + 4 },
      end: { x: boxX + boxWidth - 10, y: currentY + 4 },
      thickness: 0.75,
      color: rgb(0.7, 0.75, 0.8),
    });

    // Total
    targetPage.drawText('TOTAL PAYABLE:', {
      x: boxX + 10,
      y: currentY - 10,
      size: 10,
      font: helveticaBold,
      color: rgb(0.06, 0.09, 0.16),
    });

    targetPage.drawText(`INR ${total.toFixed(2)}`, {
      x: boxX + boxWidth - 65,
      y: currentY - 10,
      size: 10,
      font: helveticaBold,
      color: rgb(0.1, 0.5, 0.2),
    });
  }

  // Save new PDF into FinalDocuments/
  const finalPdfBytes = await pdfDoc.save();
  const safeJobId = publicJobId.replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeJobId}_final.pdf`;
  const finalFilePath = path.join(DIRS.finalDocs, filename);

  fs.writeFileSync(finalFilePath, finalPdfBytes);

  return {
    finalFilePath,
    filename,
    size: finalPdfBytes.byteLength,
  };
}

export async function saveDirectPortalPdf(
  originalPdfPath: string,
  publicJobId: string,
  originalFilename?: string
): Promise<{ finalFilePath: string; filename: string; size: number }> {
  if (!fs.existsSync(originalPdfPath)) {
    throw new Error('Original file does not exist at ' + originalPdfPath);
  }

  const ext = originalFilename
    ? path.extname(originalFilename).toLowerCase().replace('.', '') || 'pdf'
    : path.extname(originalPdfPath).toLowerCase().replace('.', '') || 'pdf';

  const safeJobId = publicJobId.replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeJobId}_final.${ext}`;
  const finalFilePath = path.join(DIRS.finalDocs, filename);

  // Copy without modifying original
  fs.copyFileSync(originalPdfPath, finalFilePath);
  const stat = fs.statSync(finalFilePath);

  return {
    finalFilePath,
    filename,
    size: stat.size,
  };
}

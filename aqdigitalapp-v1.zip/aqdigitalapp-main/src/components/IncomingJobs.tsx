import React, { useState } from 'react';
import {
  Inbox,
  FileText,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldAlert,
  ShieldCheck,
  Ban,
  Send,
  Eye,
  AlertTriangle,
  RefreshCw,
  Search,
  Download,
  Copy,
  Check
} from 'lucide-react';
import { Job, JobStatus } from '../types';

interface IncomingJobsProps {
  jobs: Job[];
  onRefresh: () => void;
  onAccept: (jobId: string) => void;
  onReject: (jobId: string, reason: string) => void;
  onTerminate: (jobId: string) => void;
  onOpenPdfStudio: (job: Job) => void;
}

export const IncomingJobs: React.FC<IncomingJobsProps> = ({
  jobs,
  onRefresh,
  onAccept,
  onReject,
  onTerminate,
  onOpenPdfStudio,
}) => {
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [rejectModalJob, setRejectModalJob] = useState<Job | null>(null);
  const [rejectReason, setRejectReason] = useState('Unsupported or invalid file format');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(text);
    }
    setCopiedPath(key);
    setTimeout(() => setCopiedPath(null), 2500);
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const getStatusBadge = (status: JobStatus) => {
    switch (status) {
      case 'NEW':
      case 'UPLOADING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <Clock className="w-3 h-3 animate-spin" />
            Uploading
          </span>
        );
      case 'SCANNING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            <ShieldAlert className="w-3 h-3 animate-pulse" />
            Scanning
          </span>
        );
      case 'WAITING_ACCEPTANCE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
            <Clock className="w-3 h-3 text-amber-700 animate-spin" />
            Awaiting Accept (1m limit)
          </span>
        );
      case 'CLEAN':
      case 'ACCEPTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <ShieldCheck className="w-3 h-3" />
            Accepted / Processing
          </span>
        );
      case 'PUBLISHED':
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-800 border border-slate-300">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Finished
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-200">
            <XCircle className="w-3 h-3" />
            Rejected
          </span>
        );
      case 'TERMINATED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Ban className="w-3 h-3" />
            Terminated
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const filteredJobs = jobs.filter((j) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      j.public_job_id.toLowerCase().includes(q) ||
      (j.customer_name && j.customer_name.toLowerCase().includes(q)) ||
      (j.notes && j.notes.toLowerCase().includes(q))
    );
  });

  return (
    <div id="incoming-jobs-view" className="space-y-4">
      {/* Search & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            id="input-search-jobs"
            type="text"
            placeholder="Search by Job ID, customer, or notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2">
          <button
            id="btn-refresh-jobs"
            onClick={onRefresh}
            className="flex items-center space-x-1.5 px-3 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Jobs Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <th className="py-3 px-4">Job ID</th>
                <th className="py-3 px-4">Customer / Notes</th>
                <th className="py-3 px-4">Files</th>
                <th className="py-3 px-4">Total Size</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Created Time</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredJobs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    <Inbox className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-medium text-sm text-slate-600">No incoming jobs yet</p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Customer uploads over Wi-Fi will appear here instantly.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredJobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {job.public_job_id}
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      <div className="font-semibold text-slate-800">
                        {job.customer_name || 'Walk-in Customer'}
                      </div>
                      {job.notes && (
                        <div className="text-[11px] text-slate-500 truncate max-w-xs" title={job.notes}>
                          {job.notes}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">
                      {job.file_count || (job.files ? job.files.length : 0)} file(s)
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-medium">
                      {formatBytes(job.total_size)}
                    </td>
                    <td className="py-3 px-4">
                      {getStatusBadge(job.status)}
                      {job.status === 'WAITING_ACCEPTANCE' && (
                        <div className="text-[11px] font-bold text-amber-700 mt-1 flex items-center gap-1">
                          <Clock className="w-3 h-3 animate-spin" />
                          <span>{job.time_remaining_seconds !== null && job.time_remaining_seconds !== undefined ? `${job.time_remaining_seconds}s to accept` : '60s limit'}</span>
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                      {new Date(job.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                      {/* View details */}
                      <button
                        id={`btn-view-job-${job.public_job_id}`}
                        onClick={() => setSelectedJob(job)}
                        className="px-2 py-1 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md font-semibold transition-colors"
                        title="View File Details"
                      >
                        <Eye className="w-3.5 h-3.5 inline mr-1" />
                        Files
                      </button>

                      {/* Terminate (if still uploading) */}
                      {['NEW', 'UPLOADING'].includes(job.status) && (
                        <button
                          id={`btn-terminate-job-${job.public_job_id}`}
                          onClick={() => onTerminate(job.id)}
                          className="px-2 py-1 text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-md font-semibold transition-colors"
                          title="Terminate Upload Immediately"
                        >
                          <Ban className="w-3.5 h-3.5 inline mr-1" />
                          Terminate
                        </button>
                      )}

                      {/* Accept */}
                      {['NEW', 'UPLOAD_COMPLETE', 'CLEAN', 'WAITING_ACCEPTANCE'].includes(job.status) && (
                        <button
                          id={`btn-accept-job-${job.public_job_id}`}
                          onClick={() => onAccept(job.id)}
                          className={`px-2.5 py-1 text-white rounded-md font-semibold transition-colors shadow-xs ${
                            job.status === 'WAITING_ACCEPTANCE'
                              ? 'bg-emerald-600 hover:bg-emerald-700 animate-pulse ring-2 ring-emerald-400/50'
                              : 'bg-emerald-600 hover:bg-emerald-700'
                          }`}
                          title="Accept customer job"
                        >
                          Accept
                        </button>
                      )}

                      {/* Reject */}
                      {!['REJECTED', 'TERMINATED', 'PUBLISHED'].includes(job.status) && (
                        <button
                          id={`btn-reject-job-${job.public_job_id}`}
                          onClick={() => setRejectModalJob(job)}
                          className="px-2 py-1 text-red-600 hover:bg-red-50 rounded-md font-medium transition-colors"
                        >
                          Reject
                        </button>
                      )}

                      {/* Return Document / Edit PDF */}
                      {['ACCEPTED', 'PROCESSING', 'CLEAN', 'PUBLISHED'].includes(job.status) && (
                        <button
                          id={`btn-return-doc-${job.public_job_id}`}
                          onClick={() => onOpenPdfStudio(job)}
                          className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-semibold transition-colors shadow-xs"
                        >
                          <Send className="w-3 h-3 inline mr-1" />
                          {job.status === 'PUBLISHED' ? 'Republish PDF' : 'Return PDF'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Job File Details Modal */}
      {selectedJob && (
        <div id="modal-job-details" className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-sm">
                  {selectedJob.public_job_id}
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-1">
                  Customer Job Files & Security Audit
                </h3>
              </div>
              <button
                onClick={() => setSelectedJob(null)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-400 block">Customer</span>
                <span className="font-semibold text-slate-800">{selectedJob.customer_name || 'Walk-in'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Status</span>
                <span className="font-semibold text-slate-800">{selectedJob.status}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Total Files</span>
                <span className="font-semibold text-slate-800">{selectedJob.file_count}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Total Size</span>
                <span className="font-semibold text-slate-800">{formatBytes(selectedJob.total_size)}</span>
              </div>
            </div>

            {selectedJob.notes && (
              <div className="text-xs bg-blue-50/70 p-3 rounded-xl border border-blue-200">
                <span className="font-bold text-blue-900 block mb-0.5">Customer Instructions:</span>
                <p className="text-slate-800">{selectedJob.notes}</p>
              </div>
            )}

            {/* Storage Location on Disk */}
            <div className="bg-slate-900 text-slate-100 p-3.5 rounded-xl flex items-center justify-between gap-3 text-xs shadow-xs">
              <div className="overflow-hidden">
                <span className="text-slate-400 block text-[10px] font-semibold uppercase tracking-wider">Host PC Storage Directory</span>
                <span className="font-mono text-emerald-400 text-xs truncate block select-all">
                  {selectedJob.storage_dir || `storage/jobs/${selectedJob.public_job_id}`}
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(selectedJob.storage_dir || `storage/jobs/${selectedJob.public_job_id}`, 'job-dir')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs font-semibold shrink-0 transition-colors"
                title="Copy folder location on disk"
              >
                {copiedPath === 'job-dir' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedPath === 'job-dir' ? 'Copied' : 'Copy Folder'}
              </button>
            </div>

            {/* 1-Minute Acceptance Alert in Modal */}
            {selectedJob.status === 'WAITING_ACCEPTANCE' && (
              <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl flex items-center justify-between gap-3 text-xs text-amber-900">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-600 animate-spin shrink-0" />
                  <div>
                    <span className="font-bold block">1-Minute Acceptance Window Active</span>
                    <span className="text-amber-700">
                      Auto-rejects in {selectedJob.time_remaining_seconds !== null && selectedJob.time_remaining_seconds !== undefined ? `${selectedJob.time_remaining_seconds}s` : '60s'} if not accepted.
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Files List */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Uploaded Files ({selectedJob.files?.length || 0})
              </h4>
              <div className="space-y-2.5">
                {selectedJob.files && selectedJob.files.length > 0 ? (
                  selectedJob.files.map((file) => (
                    <div
                      key={file.id}
                      className="p-3 bg-white rounded-xl border border-slate-200 flex flex-col gap-2 text-xs hover:border-slate-300 transition-colors"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-start space-x-2.5 overflow-hidden">
                          <FileText className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                          <div className="truncate">
                            <p className="font-semibold text-slate-800 truncate" title={file.original_filename}>
                              {file.original_filename}
                            </p>
                            <div className="flex items-center space-x-2 text-[11px] text-slate-400 mt-0.5">
                              <span>Safe: {file.safe_filename}</span>
                              <span>•</span>
                              <span>{formatBytes(file.size)}</span>
                              <span>•</span>
                              <span className="font-mono">{file.signature_type}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          {file.scan_status === 'CLEAN' ? (
                            <>
                              <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 text-[11px]">
                                <ShieldCheck className="w-3 h-3" />
                                Clean
                              </span>
                              <a
                                id={`btn-download-file-${file.id}`}
                                href={`/api/operator/jobs/${selectedJob.id}/files/${file.id}/download`}
                                download={file.original_filename}
                                className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-200 hover:border-blue-200 rounded-md font-semibold text-[11px] transition-colors"
                                title="Download / Open file on operator PC"
                              >
                                <Download className="w-3 h-3" />
                                Open
                              </a>
                            </>
                          ) : file.scan_status === 'THREAT_DETECTED' ? (
                            <span className="inline-flex items-center gap-1 text-red-700 font-semibold bg-red-50 px-2 py-0.5 rounded-full border border-red-200 text-[11px]">
                              <ShieldAlert className="w-3 h-3" />
                              Threat Detected
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 text-[11px]">
                              <Clock className="w-3 h-3" />
                              {file.scan_status}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* File saved location detail */}
                      <div className="flex items-center justify-between gap-2 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-200/70 text-[11px] font-mono text-slate-600">
                        <span className="truncate select-all" title={file.storage_path || `${selectedJob.storage_dir || `storage/jobs/${selectedJob.public_job_id}`}/${file.safe_filename}`}>
                          {file.storage_path || `${selectedJob.storage_dir || `storage/jobs/${selectedJob.public_job_id}`}/${file.safe_filename}`}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopy(file.storage_path || `${selectedJob.storage_dir || `storage/jobs/${selectedJob.public_job_id}`}/${file.safe_filename}`, `file-${file.id}`)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[10px] font-sans font-semibold shrink-0 transition-colors"
                          title="Copy path to clipboard"
                        >
                          {copiedPath === `file-${file.id}` ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          {copiedPath === `file-${file.id}` ? 'Copied' : 'Copy Path'}
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-400 py-4 text-center">No file details available yet</p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              {selectedJob.status === 'WAITING_ACCEPTANCE' ? (
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      const jobToReject = selectedJob;
                      setSelectedJob(null);
                      setRejectModalJob(jobToReject);
                    }}
                    className="px-3.5 py-2 text-red-600 hover:bg-red-50 border border-red-200 rounded-lg text-xs font-semibold transition-colors"
                  >
                    Reject Job
                  </button>
                  <button
                    onClick={() => {
                      onAccept(selectedJob.id);
                      setSelectedJob(null);
                    }}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition-colors shadow-xs"
                  >
                    Accept Job Now
                  </button>
                </div>
              ) : (
                <div />
              )}
              <button
                onClick={() => setSelectedJob(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Reason Dialog */}
      {rejectModalJob && (
        <div id="modal-reject-reason" className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-xl border border-slate-200 space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Reject Job {rejectModalJob.public_job_id}
            </h3>
            <p className="text-slate-600">
              Please specify a reason. The customer will see this message on their phone.
            </p>

            <div className="space-y-2">
              {[
                'Unsupported or invalid file format',
                'Wrong document / Unreadable scan',
                'Malware or security signature detected',
                'Customer cancelled or left shop',
                'Customer exceeded file limits',
              ].map((reason) => (
                <label key={reason} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="rejectReason"
                    checked={rejectReason === reason}
                    onChange={() => setRejectReason(reason)}
                    className="text-red-600 focus:ring-red-500"
                  />
                  <span className="text-slate-700 font-medium">{reason}</span>
                </label>
              ))}
            </div>

            <textarea
              placeholder="Or enter custom reason..."
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full p-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-red-500"
              rows={2}
            />

            <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setRejectModalJob(null)}
                className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onReject(rejectModalJob.id, rejectReason);
                  setRejectModalJob(null);
                }}
                className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold shadow-xs"
              >
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import {
  History,
  Search,
  Filter,
  Calendar,
  Download,
  FileText,
  CheckCircle2,
  XCircle,
  Clock,
  Ban,
  Eye,
  ArrowUpDown
} from 'lucide-react';
import { Job, JobStatus } from '../types';

interface JobHistoryProps {
  jobs: Job[];
  onOpenDetails: (job: Job) => void;
}

export const JobHistoryView: React.FC<JobHistoryProps> = ({ jobs, onOpenDetails }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | 'YESTERDAY' | 'WEEK' | 'MONTH'>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const getStatusBadge = (status: JobStatus) => {
    switch (status) {
      case 'PUBLISHED':
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Finished
          </span>
        );
      case 'ACCEPTED':
      case 'CLEAN':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            Accepted
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-200">
            <XCircle className="w-3 h-3" />
            Rejected
          </span>
        );
      case 'TERMINATED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Ban className="w-3 h-3" />
            Terminated
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const yesterdayStr = yesterday.toISOString().slice(0, 10);

  const filteredJobs = jobs.filter((job) => {
    // Search query filter
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchPublicId = job.public_job_id.toLowerCase().includes(q);
      const matchCustomer = job.customer_name?.toLowerCase().includes(q);
      const matchNotes = job.notes?.toLowerCase().includes(q);
      const matchFiles = job.files?.some((f) => f.original_filename.toLowerCase().includes(q));
      if (!matchPublicId && !matchCustomer && !matchNotes && !matchFiles) return false;
    }

    // Status filter
    if (statusFilter !== 'ALL') {
      if (statusFilter === 'COMPLETED' && !['COMPLETED', 'PUBLISHED'].includes(job.status)) return false;
      if (statusFilter === 'REJECTED' && job.status !== 'REJECTED') return false;
      if (statusFilter === 'TERMINATED' && job.status !== 'TERMINATED') return false;
    }

    // Date filter
    if (dateFilter === 'TODAY') {
      return job.created_at.startsWith(todayStr);
    }
    if (dateFilter === 'YESTERDAY') {
      return job.created_at.startsWith(yesterdayStr);
    }
    if (dateFilter === 'WEEK') {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      return job.created_at >= weekAgo;
    }
    if (dateFilter === 'MONTH') {
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
      return job.created_at >= monthAgo;
    }

    return true;
  });

  const exportCsv = () => {
    const headers = ['Job ID', 'Customer', 'Status', 'File Count', 'Total Size (Bytes)', 'Created At', 'Completed At', 'Rejection Reason'];
    const rows = filteredJobs.map((j) => [
      j.public_job_id,
      `"${(j.customer_name || 'Walk-in').replace(/"/g, '""')}"`,
      j.status,
      j.file_count,
      j.total_size,
      j.created_at,
      j.completed_at || j.published_at || '',
      `"${(j.rejection_reason || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `AQ_DIGITAL_Job_History_${todayStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="job-history-view" className="space-y-5">
      {/* Top Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            id="input-history-search"
            type="text"
            placeholder="Search by Job ID, customer, file name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:border-blue-500 bg-white"
          />
        </div>

        {/* Date Filter Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {(['ALL', 'TODAY', 'YESTERDAY', 'WEEK', 'MONTH'] as const).map((d) => (
            <button
              key={d}
              onClick={() => setDateFilter(d)}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                dateFilter === d
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {d === 'ALL' ? 'All Time' : d.charAt(0) + d.slice(1).toLowerCase()}
            </button>
          ))}

          {/* Status Dropdown */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200"
          >
            <option value="ALL">All Statuses</option>
            <option value="COMPLETED">Finished Only</option>
            <option value="REJECTED">Rejected Only</option>
            <option value="TERMINATED">Terminated Only</option>
          </select>

          {/* Export CSV */}
          <button
            id="btn-export-history-csv"
            onClick={exportCsv}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
            title="Export filtered records as CSV spreadsheet"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <th className="py-3 px-4">Job ID</th>
                <th className="py-3 px-4">Customer Name</th>
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-4">Files</th>
                <th className="py-3 px-4">Total Size</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredJobs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    <History className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-slate-700 text-sm">No job records found</p>
                    <p className="text-xs text-slate-400 mt-0.5">Try adjusting your search or date filters.</p>
                  </td>
                </tr>
              ) : (
                filteredJobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {job.public_job_id}
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {job.customer_name || 'Walk-in'}
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                      {new Date(job.created_at).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">
                      {job.file_count || (job.files ? job.files.length : 0)} file(s)
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-medium">
                      {formatBytes(job.total_size)}
                    </td>
                    <td className="py-3 px-4">
                      {getStatusBadge(job.status)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onOpenDetails(job)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-md font-semibold transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5 inline mr-1" />
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

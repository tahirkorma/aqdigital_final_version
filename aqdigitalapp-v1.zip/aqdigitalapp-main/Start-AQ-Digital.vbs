﻿' =========================================================================
'  AQ DIGITAL File Desk - One-Click Silent Launcher (No Command Prompt)
'  Double-click this file to start AQ DIGITAL.
' =========================================================================

Option Explicit
Dim WshShell, fso, ScriptDir, ServerScript, oExec, errCode, answer, Command

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Current folder where the script is placed
ScriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Check if Node.js is installed
On Error Resume Next
Set oExec = WshShell.Exec("node -v")
errCode = Err.Number
On Error GoTo 0

If errCode <> 0 Then
    answer = MsgBox("Node.js is not installed on this PC." & vbCrLf & vbCrLf & _
                    "AQ DIGITAL needs Node.js to run locally on your shop PC." & vbCrLf & vbCrLf & _
                    "Click [Yes] to open the official free Node.js installer download page.", _
                    vbYesNo + vbInformation + vbSystemModal, "AQ DIGITAL - Quick Setup")
    If answer = vbYes Then
        WshShell.Run "https://nodejs.org/en/download"
    End If
    WScript.Quit 1
End If

' Verify that dist/server.cjs is present
ServerScript = ScriptDir & "\dist\server.cjs"
If Not fso.FileExists(ServerScript) Then
    MsgBox "The application files were not found." & vbCrLf & _
           "Missing: dist\server.cjs" & vbCrLf & vbCrLf & _
           "Please ensure all extracted files remain in this folder.", _
           vbCritical + vbSystemModal, "AQ DIGITAL - File Missing"
    WScript.Quit 1
End If

' Launch server completely hidden in background (window style 0 = hidden)
Command = "cmd.exe /c cd /d """ & ScriptDir & """ && set ""NODE_ENV=production"" && node dist/server.cjs"
WshShell.Run Command, 0, False

' Wait 3 seconds for the local server to bind port 3000
WScript.Sleep 3000

' Automatically open the Operator Desk in the default browser
WshShell.Run "http://localhost:3000"

# How to Run AQ DIGITAL on Any PC (Zero Command Prompt Required)

This guide walks you through running or installing **AQ DIGITAL File Desk** on your Windows PC with **zero commands** to type.

---

### Step 1: Download the App from Google AI Studio

1. In the upper-right corner of the **Google AI Studio** window, click the **Settings / Menu icon** (or the **Share / Export** menu).
2. Click **"Download as ZIP"** (or export to GitHub).
3. Save the ZIP file to your PC and extract it into any folder (for example `C:\AQ-Digital` or your `Desktop`).

---

### Step 2: One-Time Prerequisite

The app runs locally using Node.js:
- If your PC already has Node.js, you're all set!
- If not, download and run the standard official installer from [nodejs.org](https://nodejs.org) (LTS version).

*(You will NEVER need to open the command prompt or type commands).*

---

### Step 3: Run or Install with 1 Click

In your extracted folder, choose whichever option fits your workflow best:

#### Option A: 1-Click Desktop Installer (Recommended)
- Double-click **`Install-Desktop-App.bat`**.
- It creates an **"AQ DIGITAL File Desk"** shortcut icon directly on your Windows Desktop.
- From then on, simply **double-click your Desktop icon** anytime to open the desk like any native desktop software!

#### Option B: Silent Background Launcher (No Console Window)
- Double-click **`Start-AQ-Digital.vbs`**.
- The app launches silently in the background with **zero black terminal windows**.
- It automatically opens your web browser (Chrome, Edge, etc.) directly to:
  ```
  http://localhost:3000
  ```

#### Option C: Standard Portable Batch Launcher
- Double-click **`run.bat`**.
- Displays the local status and opens your browser immediately.

---

### How to Stop / Close the Server

When you close your shop at the end of the day:
- Double-click **`Stop-AQ-Digital.bat`** (or click the **Power / Exit** button in the top navigation bar of the Operator screen).
- The background server will shut down safely.

---

### Step 4: Optional Single-File Windows Installer (`AQ-Digital-Setup.exe`)

If you want an official single-file Windows installer to distribute across multiple shop counter PCs:
1. Install [Inno Setup 6](https://jrsoftware.org/isdl.php) (free Windows setup compiler).
2. Double-click **`build_windows.bat`**.
3. It compiles:
   ```
   dist_installer\AQ-Digital-Setup.exe
   ```
4. Double-click `AQ-Digital-Setup.exe` on any PC to install it via a standard Windows installation wizard with Start Menu entries, desktop icons, and automated Windows Firewall configuration.

@echo off
setlocal
title Install AQ DIGITAL Desktop App
echo ===================================================
echo     AQ DIGITAL File Desk - 1-Click Desktop Setup
echo ===================================================
echo.
echo [*] Creating Desktop shortcut...

set "TARGET=%~dp0Start-AQ-Digital.vbs"
set "WORKINGDIR=%~dp0"
set "DESKTOP=%USERPROFILE%\Desktop"

REM Use built-in Windows PowerShell to create the standard .lnk shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\AQ DIGITAL File Desk.lnk'); $s.TargetPath = 'wscript.exe'; $s.Arguments = '\"%TARGET%\"'; $s.WorkingDirectory = '%WORKINGDIR%'; $s.Description = 'AQ DIGITAL File Desk - Secure Local Transfer'; $s.Save()"

if exist "%DESKTOP%\AQ DIGITAL File Desk.lnk" (
    echo [SUCCESS] "AQ DIGITAL File Desk" icon has been created on your Desktop!
    echo.
    echo [*] Starting the app now...
    start "" wscript.exe "%TARGET%"
) else (
    echo [NOTICE] You can run 'Start-AQ-Digital.vbs' directly or right-click it and choose 'Send to -^> Desktop (create shortcut)'.
)

echo.
timeout /t 3 >nul
